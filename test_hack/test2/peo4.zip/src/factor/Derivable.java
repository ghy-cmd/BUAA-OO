package factor;

import factor.Factor;

import java.util.ArrayList;

public interface Derivable {
    public ArrayList<Factor> derive();
}
