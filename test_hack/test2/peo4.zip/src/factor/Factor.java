package factor;

public class Factor {

}
