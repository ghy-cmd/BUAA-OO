import com.oocourse.elevator3.ElevatorInput;
import com.oocourse.elevator3.ElevatorRequest;
import com.oocourse.elevator3.PersonRequest;
import com.oocourse.elevator3.Request;
import objects.RequestPerson;
import objects.WaitQueue;

import java.io.IOException;

public class InputThread extends Thread {
    private final WaitQueue waitQueue;
    private final String arrivePattern;
    private final ElevatorInput elevatorInput;

    public InputThread(ElevatorInput elevatorInput, WaitQueue waitQueue, String arrivePattern) {
        this.waitQueue = waitQueue;
        this.elevatorInput = elevatorInput;
        this.arrivePattern = arrivePattern;
    }

    @Override
    public void run() {
        /*TimableOutput.initStartTimestamp();*/
        while (true) {
            Request stuRequest = elevatorInput.nextRequest();
            //System.out.println(stuRequest);
            //System.out.println(waitQueue);

            if (stuRequest == null) {
                synchronized (waitQueue) {
                    waitQueue.close();
                    waitQueue.notifyAll();
                    //不同点
                    try {
                        elevatorInput.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.err.println("input close");
                    return;
                }
            } else {
                // a new valid request
                //System.out.println(request);
                if (stuRequest instanceof PersonRequest) {
                    synchronized (waitQueue) {
                        RequestPerson request =
                            new RequestPerson(((PersonRequest) stuRequest).getPersonId(),
                                ((PersonRequest) stuRequest).getFromFloor(),
                                ((PersonRequest) stuRequest).getToFloor());
                        waitQueue.addRequest(request);
                        waitQueue.notifyAll();
                    }
                } else if (stuRequest instanceof ElevatorRequest) {
                    if (((ElevatorRequest) stuRequest).getElevatorType().equals("A")) {
                        Elevator elevator;
                        synchronized (waitQueue) {
                            elevator =
                                new Elevator(waitQueue, arrivePattern,
                                    ((ElevatorRequest) stuRequest).getElevatorId());
                        }
                        System.err.println(
                            "elevator" + ((ElevatorRequest) stuRequest).getElevatorId() + " start");
                        elevator.start();
                    } else if (((ElevatorRequest) stuRequest).getElevatorType().equals("B")) {
                        ElevatorB elevator;
                        synchronized (waitQueue) {
                            elevator = new ElevatorB(waitQueue, arrivePattern,
                                ((ElevatorRequest) stuRequest).getElevatorId());
                        }
                        System.err.println(
                            "elevator" + ((ElevatorRequest) stuRequest).getElevatorId() + " start");
                        elevator.start();
                    } else {
                        ElevatorC elevator;
                        synchronized (waitQueue) {
                            elevator = new ElevatorC(waitQueue, arrivePattern,
                                ((ElevatorRequest) stuRequest).getElevatorId());
                        }
                        System.err.println(
                            "elevator" + ((ElevatorRequest) stuRequest).getElevatorId() + " start");
                        elevator.start();
                    }
                }
            }
        }
    }
}