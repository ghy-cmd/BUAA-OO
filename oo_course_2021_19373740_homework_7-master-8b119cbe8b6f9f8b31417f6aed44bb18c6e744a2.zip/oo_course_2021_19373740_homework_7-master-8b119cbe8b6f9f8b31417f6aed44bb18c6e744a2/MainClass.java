import com.oocourse.TimableOutput;
import com.oocourse.elevator3.ElevatorInput;
import objects.WaitQueue;

public class MainClass {
    public static void main(String[] args) throws Exception {
        TimableOutput.initStartTimestamp();
        WaitQueue waitQueue = new WaitQueue();
        /*String arrivePattern = new String();*/
        ElevatorInput elevatorInput = new ElevatorInput(System.in);
        String arrivePattern = elevatorInput.getArrivingPattern();

        InputThread inputThread = new InputThread(elevatorInput, waitQueue, arrivePattern);
        inputThread.start();

        Elevator elevator1 = new Elevator(waitQueue, arrivePattern, "1");
        System.err.println("elevator1 start");
        elevator1.start();
        ElevatorB elevator2 = new ElevatorB(waitQueue, arrivePattern, "2");
        System.err.println("elevator2 start");
        elevator2.start();
        ElevatorC elevator3 = new ElevatorC(waitQueue, arrivePattern, "3");
        System.err.println("elevator3 start");
        elevator3.start();
    }
}
