package objects;

public class RequestPerson {
    private int personId;
    private int leaveFloor;
    private int arriveFloor;

    public RequestPerson(int personId, int leaveFloor, int arriveFloor) {
        this.personId = personId;
        this.leaveFloor = leaveFloor;
        this.arriveFloor = arriveFloor;
    }

    public int getPersonId() {
        return personId;
    }

    public int getArriveFloor() {
        return arriveFloor;
    }

    public int getLeaveFloor() {
        return leaveFloor;
    }

    public Boolean isC() {
        Boolean right =
            ((leaveFloor >= 1 && leaveFloor <= 3) || (leaveFloor >= 18 && leaveFloor <= 20)) &&
                ((arriveFloor >= 1 && arriveFloor <= 3) ||
                    (arriveFloor >= 18 && arriveFloor <= 20));
        return right;
    }
}
