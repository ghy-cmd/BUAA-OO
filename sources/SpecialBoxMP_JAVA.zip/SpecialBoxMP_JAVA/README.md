# Special Box Manage Platform

Spring Boot Server 


## Overview  
```shell
git clone https://codeup.aliyun.com/bhcz/bhczlab/SpecialBoxMP_JAVA.git
```

API Path
http://localhost:8080/api/

Change default port value in application.properties