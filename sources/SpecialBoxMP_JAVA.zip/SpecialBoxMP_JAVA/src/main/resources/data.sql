-- 初始化默认角色
-- 初始化管理员账号密码: admin admin
-- 关联权限

INSERT INTO t_role
    (role_id, role_name)
SELECT 3,
       'ROLE_CUSTOMER' WHERE
 NOT EXISTS(
     SELECT role_name FROM t_role WHERE role_name = 'ROLE_ADMIN'
     );
INSERT INTO t_role
    (role_id, role_name)
SELECT 2,
       'ROLE_EMPLOYEE' WHERE
    NOT EXISTS(
            SELECT role_name FROM t_role WHERE role_name = 'ROLE_ADMIN'
        );

INSERT INTO t_user
(user_id, user_email, user_name, user_password, user_phone, user_status, user_telephone, user_username)
SELECT 10000000,
       null,
       null,
       '$e0801$6O0SKQaWcCSakTFIJo4XNwBHywNAp2dYxBjaTpMu4/Ez5fir+R46NUjIet1VrVAoc9hx51hpNGh/P+i+vBg+ug==$62NTfXo/HEyxgHG97FldFW7l1RyE3qJk0o1akfR7JFA=',
       null,
       1,
       null,
       'admin' WHERE
    NOT EXISTS(
        SELECT role_name FROM t_role WHERE role_name = 'ROLE_ADMIN'
         );

INSERT INTO t_role
    (role_id, role_name)
SELECT 1,
       'ROLE_ADMIN' WHERE
    NOT EXISTS(
            SELECT role_name FROM t_role WHERE role_name = 'ROLE_ADMIN'
        );

INSERT INTO t_user_role
    (uid, rid)
SELECT 10000000,
       1 WHERE
    NOT EXISTS(
        SELECT rid FROM t_user_role WHERE rid = 1
        );