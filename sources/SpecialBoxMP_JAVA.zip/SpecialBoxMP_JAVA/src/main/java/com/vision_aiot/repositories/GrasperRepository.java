package com.vision_aiot.repositories;

import com.vision_aiot.model.Grasper;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface GrasperRepository extends JpaRepository<Grasper, Long> {
    List<Grasper> findAll();

    Optional<Grasper> findGrasperByGrasperId(Long id);

    void deleteGrasperByGrasperId(Long id);

    Optional<Grasper> findGrasperByGrasperName(String grasperName);
}
