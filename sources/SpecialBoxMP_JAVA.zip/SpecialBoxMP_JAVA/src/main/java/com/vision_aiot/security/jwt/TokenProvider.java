package com.vision_aiot.security.jwt;

import com.vision_aiot.model.User;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import java.io.*;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collection;
import java.util.Date;
import java.util.stream.Collectors;

/**
 * @author 杨钰杰
 * @implNote JWT工具类，已实现生成、验证和解析Json Web Token
 * @// TODO: 异常处理部分
 */

@Component
public class TokenProvider implements InitializingBean {
    
    private static final Logger logger = LoggerFactory.getLogger(TokenProvider.class);
    
    private static final String AUTHORITIES_KEY = "auth";
    
    private final long tokenValidityInMilliseconds;
    private final long tokenValidityInMillisecondsForRememberMe;
    
    private KeyPair keyPair;
    
    /**
     * 初始化JWT函数
     * 默认加密算法 RSA 4096
     * 配置中需要添加
     * 1. jwt.token-validity-in-seconds 没有记住密码时超时时间
     * 2. jwt.token-validity-in-seconds-for-remember-me  记住密码时超时时间
     * 3. jwt.keypair.public  公钥路径(无文件默认生成RSA 4096的公钥)
     * 4. jwt.keypair.private  私钥路径(无文件默认生成RSA 4096的密钥)
     *
     * @param certRootPath                        存放证书的目录
     * @param privateKeyName                      私钥文件名
     * @param publicKeyName                       公钥文件名
     * @param tokenValidityInSeconds              不记住密码的超时时间
     * @param tokenValidityInSecondsForRememberMe 记住密码的超时时间
     */
    public TokenProvider(
            @Value("${jwt.keypair.path}") String certRootPath,
            @Value("${jwt.keypair.public}") String publicKeyName,
            @Value("${jwt.keypair.private}") String privateKeyName,
            @Value("${jwt.token-validity-in-seconds}") long tokenValidityInSeconds,
            @Value("${jwt.token-validity-in-seconds-for-remember-me}") long tokenValidityInSecondsForRememberMe
    ) {
        this.tokenValidityInMilliseconds = tokenValidityInSeconds;
        this.tokenValidityInMillisecondsForRememberMe = tokenValidityInSecondsForRememberMe;
        
        PublicKey publicKey = null;
        PrivateKey privateKey = null;
        try {
            File certRootDir = new File(certRootPath);
            // 载入密钥对， 密钥对统一使用BASE64编码格式进行编码
            File publicKeyFile = new File(certRootPath + publicKeyName);
            File privateKeyFile = new File(certRootPath + privateKeyName);
            
            // 判断密钥目录是否存在，不存在则创建目录
            if (!certRootDir.exists()) {
                if (!certRootDir.mkdirs()) {
                    System.out.println("ERROR: cannot make directory.");
                }
            }
            
            // 判断密钥对是否存在
            if (privateKeyFile.exists() || publicKeyFile.exists()) { // 存在密钥文件
                // base64解码器
                Base64.Decoder base64Decoder = Base64.getDecoder();
                // 配置输入流
                InputStream publicKeyInputStream = new FileInputStream(publicKeyFile);
                InputStream privateKeyInputStream = new FileInputStream(privateKeyFile);
                
                // 读取公钥
                X509EncodedKeySpec encodedPublicKeySpec = new X509EncodedKeySpec(base64Decoder.decode(publicKeyInputStream.readAllBytes()));
                publicKeyInputStream.close();
                publicKey = KeyFactory.getInstance("RSA").generatePublic(encodedPublicKeySpec);
                
                // 读取私钥
                PKCS8EncodedKeySpec encodedPrivateKeySpec = new PKCS8EncodedKeySpec(base64Decoder.decode(privateKeyInputStream.readAllBytes()));
                privateKeyInputStream.close();
                privateKey = KeyFactory.getInstance("RSA").generatePrivate(encodedPrivateKeySpec);
                
                // 赋值
                this.keyPair = new KeyPair(publicKey, privateKey);
            } else { // 密钥文件不存在
                // 生成新的密钥对
                this.keyPair = Keys.keyPairFor(SignatureAlgorithm.RS512);
                publicKey = keyPair.getPublic();
                privateKey = keyPair.getPrivate();
                
                // 将公钥经BASE64编码后写入文件
                OutputStream publicKeyOutputStream = new FileOutputStream(publicKeyFile);
                Base64.Encoder base64Encoder = Base64.getEncoder();
                publicKeyOutputStream.write(base64Encoder.encode(publicKey.getEncoded()));
                publicKeyOutputStream.flush();
                publicKeyOutputStream.close();
                
                // 将私钥经BASE64编码后写入文件
                OutputStream privateKeyOutputStream = new FileOutputStream(privateKeyFile);
                privateKeyOutputStream.write(base64Encoder.encode(privateKey.getEncoded()));
                privateKeyOutputStream.flush();
                privateKeyOutputStream.close();
            }
        } catch (FileNotFoundException e) { // 异常接口  预留
//            e.printStackTrace();
            logger.error("error: cannot load file. " + e.getCause().toString());
        } catch (IOException e) {
            logger.error("error: IO error. " + e.getCause().toString());
        } catch (NoSuchAlgorithmException e) {
            logger.error("error: cannot found the algorithm lib. " + e.getCause().toString());
        } catch (InvalidKeySpecException e) {
            logger.error("error: cannot read the key format. " + e.getCause().toString());
            e.printStackTrace();
        }
    }
    
    @Override
    public void afterPropertiesSet() throws Exception {
    
    }
    
    /**
     * @param authentication 用户权限信息
     * @param rememberMe     是否记住密码
     * @return Json Web Token
     */
    public String createToken(Authentication authentication, boolean rememberMe) {
        String authorities = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.joining(","));
        
        long now = (new Date()).getTime();
        Date validity;
        if (rememberMe) {
            validity = new Date(now + this.tokenValidityInMillisecondsForRememberMe);
        } else {
            validity = new Date(now + this.tokenValidityInMilliseconds);
        }
        
        return Jwts.builder()
                .setSubject(authentication.getName())
                .claim(AUTHORITIES_KEY, authorities)
                .signWith(keyPair.getPrivate())
                .setExpiration(validity)
                .compact();
    }
    
    /**
     * @param token Json Web Token
     * @return 用户权限信息
     */
    public Authentication getAuthentication(String token) {
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(keyPair.getPublic()).build()
                .parseClaimsJws(token)
                .getBody();
        
        Collection<? extends GrantedAuthority> authorities =
                Arrays.stream(claims.get(AUTHORITIES_KEY).toString().split(","))
                        .map(SimpleGrantedAuthority::new)
                        .collect(Collectors.toList());
        User principal = new User(claims.getSubject(), "");
        return new UsernamePasswordAuthenticationToken(principal, token, authorities);
    }
    
    /**
     * @param authToken Json Web Token
     * @return JWT是否合法
     */
    public boolean validateToken(String authToken) {
        try {
            Jwts.parserBuilder().
                    setSigningKey(keyPair.getPublic()).build()
                    .parseClaimsJws(authToken);
            return true;
        } catch (SecurityException | MalformedJwtException e) { // 异常处理 预留记录Log
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
}