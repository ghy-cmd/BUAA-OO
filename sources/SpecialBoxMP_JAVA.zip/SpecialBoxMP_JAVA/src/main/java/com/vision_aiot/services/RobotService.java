package com.vision_aiot.services;

import com.vision_aiot.model.Robot;

import java.util.List;
import java.util.Optional;


public interface RobotService {
    int creatRobot(Robot robot);

    int creatRobotWithListInput(List<Robot> robots);

    int deleteRobot(String robotId);

    Optional<Robot> findRobotByRobotId(Long robotId);

    List<Robot> findAll();

    int updateRobot(String robotId, Robot robot);
}
