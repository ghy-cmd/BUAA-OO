package com.vision_aiot.model;

import java.io.Serializable;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Device
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-26T07:13:09.685Z[GMT]")

@Entity
@Table(name = "t_device")
public class Device implements Serializable {

    @Id
    @SequenceGenerator(sequenceName = "device_seqg", name = "device_seqg", allocationSize = 1, initialValue = 1000)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "device_seqg")
    @JsonProperty("device_id")
    @Column(name = "device_id", nullable = false, unique = true)
    private Long deviceId = null;

    @Column(name = "device_position_x", nullable = false)
    @JsonProperty("device_position_x")
    private Double devicePositionX = null;

    @Column(name = "device_position_y", nullable = false)
    @JsonProperty("device_position_y")
    private Double devicePositionY = null;

    @Column(name = "device_position_z", nullable = false)
    @JsonProperty("device_position_z")
    private Double devicePositionZ = null;

    @Column(name = "device_pose_x", nullable = false)
    @JsonProperty("device_pose_x")
    private Double devicePoseX = null;

    @Column(name = "device_pose_y", nullable = false)
    @JsonProperty("device_pose_y")
    private Double devicePoseY = null;

    @Column(name = "device_pose_z", nullable = false)
    @JsonProperty("device_pose_z")
    private Double devicePoseZ = null;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "robot_id", nullable = false)
    private Robot robot = null;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "grasper_id", nullable = false)
    private Grasper grasper = null;

    public Device deviceId(Long deviceId) {
        this.deviceId = deviceId;
        return this;
    }

    @Schema(description = "")

    public Grasper getGrasper() {
        return grasper;
    }

    public void setGrasper(Grasper grasper) {
        this.grasper = grasper;
    }

    public Device deviceGrasper(Grasper deviceGrasper) {
        this.grasper = grasper;
        return this;
    }

    @Schema(description = "")

    public Robot getRobot() {
        return robot;
    }

    public void setRobot(Robot robot) {
        this.robot = robot;
    }

    public Device deviceRobot(Robot robot) {
        this.robot = robot;
        return this;
    }

    /**
     * Get deviceId
     *
     * @return deviceId
     **/
    @Schema(description = "")

    public Long getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Long deviceId) {
        this.deviceId = deviceId;
    }

    public Device devicePositionX(Double devicePositionX) {
        this.devicePositionX = devicePositionX;
        return this;
    }

    /**
     * Get devicePositionX
     *
     * @return devicePositionX
     **/
    @Schema(description = "")

    public Double getDevicePositionX() {
        return devicePositionX;
    }

    public void setDevicePositionX(Double devicePositionX) {
        this.devicePositionX = devicePositionX;
    }

    public Device devicePositionY(Double devicePositionY) {
        this.devicePositionY = devicePositionY;
        return this;
    }

    /**
     * Get devicePositionY
     *
     * @return devicePositionY
     **/
    @Schema(description = "")

    public Double getDevicePositionY() {
        return devicePositionY;
    }

    public void setDevicePositionY(Double devicePositionY) {
        this.devicePositionY = devicePositionY;
    }

    public Device devicePositionZ(Double devicePositionZ) {
        this.devicePositionZ = devicePositionZ;
        return this;
    }

    /**
     * Get devicePositionZ
     *
     * @return devicePositionZ
     **/
    @Schema(description = "")

    public Double getDevicePositionZ() {
        return devicePositionZ;
    }

    public void setDevicePositionZ(Double devicePositionZ) {
        this.devicePositionZ = devicePositionZ;
    }

    public Device devicePoseX(Double devicePoseX) {
        this.devicePoseX = devicePoseX;
        return this;
    }

    /**
     * Get devicePoseX
     *
     * @return devicePoseX
     **/
    @Schema(description = "")

    public Double getDevicePoseX() {
        return devicePoseX;
    }

    public void setDevicePoseX(Double devicePoseX) {
        this.devicePoseX = devicePoseX;
    }

    public Device devicePoseY(Double devicePoseY) {
        this.devicePoseY = devicePoseY;
        return this;
    }

    /**
     * Get devicePoseY
     *
     * @return devicePoseY
     **/
    @Schema(description = "")

    public Double getDevicePoseY() {
        return devicePoseY;
    }

    public void setDevicePoseY(Double devicePoseY) {
        this.devicePoseY = devicePoseY;
    }

    public Device devicePoseZ(Double devicePoseZ) {
        this.devicePoseZ = devicePoseZ;
        return this;
    }

    /**
     * Get devicePoseZ
     *
     * @return devicePoseZ
     **/
    @Schema(description = "")

    public Double getDevicePoseZ() {
        return devicePoseZ;
    }

    public void setDevicePoseZ(Double devicePoseZ) {
        this.devicePoseZ = devicePoseZ;
    }


    @Override
    public boolean equals(java.lang.Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Device device = (Device) o;
        return Objects.equals(this.deviceId, device.deviceId) &&
            Objects.equals(this.devicePositionX, device.devicePositionX) &&
            Objects.equals(this.devicePositionY, device.devicePositionY) &&
            Objects.equals(this.devicePositionZ, device.devicePositionZ) &&
            Objects.equals(this.devicePoseX, device.devicePoseX) &&
            Objects.equals(this.devicePoseY, device.devicePoseY) &&
            Objects.equals(this.devicePoseZ, device.devicePoseZ);
    }

    @Override
    public int hashCode() {
        return Objects
            .hash(deviceId, devicePositionX, devicePositionY, devicePositionZ, devicePoseX,
                devicePoseY, devicePoseZ);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Device {\n");

        sb.append("    deviceId: ").append(toIndentedString(deviceId)).append("\n");
        sb.append("    devicePositionX: ").append(toIndentedString(devicePositionX)).append("\n");
        sb.append("    devicePositionY: ").append(toIndentedString(devicePositionY)).append("\n");
        sb.append("    devicePositionZ: ").append(toIndentedString(devicePositionZ)).append("\n");
        sb.append("    devicePoseX: ").append(toIndentedString(devicePoseX)).append("\n");
        sb.append("    devicePoseY: ").append(toIndentedString(devicePoseY)).append("\n");
        sb.append("    devicePoseZ: ").append(toIndentedString(devicePoseZ)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(java.lang.Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}
