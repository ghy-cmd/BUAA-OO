package com.vision_aiot.api;

import com.vision_aiot.model.Device;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vision_aiot.model.Robot;
import com.vision_aiot.security.SecurityUtils;
import com.vision_aiot.services.DeviceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-26T07:13:09.685Z[GMT]")
@RestController
public class DevicesApiController implements DevicesApi {

    private static final Logger log = LoggerFactory.getLogger(DevicesApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    private DeviceService deviceService;

    @org.springframework.beans.factory.annotation.Autowired
    public DevicesApiController(ObjectMapper objectMapper, HttpServletRequest request,
                                DeviceService deviceService) {
        this.objectMapper = objectMapper;
        this.request = request;
        this.deviceService = deviceService;
    }

    public ResponseEntity<Void> creatDevice(
        @Parameter(in = ParameterIn.DEFAULT, description = "Created device object", required = true, schema = @Schema())
        @Valid @RequestBody Device body) {
        String accept = request.getHeader("Accept");
        int result = deviceService.creatDevice(body);
        switch (result) {
            case 201:
                return new ResponseEntity<>(HttpStatus.CREATED);
            case 400:
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            case 403:
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            case 404:
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            case 409:
                return new ResponseEntity<>(HttpStatus.CONFLICT);
            default:
                return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
        }
    }

    public ResponseEntity<Void> createDevicesWithListInput(
        @Parameter(in = ParameterIn.DEFAULT, description = "List of devices object", required = true, schema = @Schema())
        @Valid @RequestBody List<Device> body) {
        String accept = request.getHeader("Accept");
        int result = deviceService.creatDeviceWithListInput(body);
        switch (result) {
            case 201:
                return new ResponseEntity<>(HttpStatus.CREATED);
            case 400:
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            case 403:
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            case 404:
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            case 409:
                return new ResponseEntity<>(HttpStatus.CONFLICT);
            default:
                return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
        }
    }

    public ResponseEntity<Void> deleteDevice(
        @Parameter(in = ParameterIn.PATH, description = "The name that needs to be deleted", required = true, schema = @Schema())
        @PathVariable("device_id") String deviceId) {
        String accept = request.getHeader("Accept");
        int result = deviceService.deleteDevice(deviceId);
        switch (result) {
            case 200:
                return new ResponseEntity<>(HttpStatus.OK);
            case 204:
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            case 400:
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            case 401:
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            case 403:
                return new ResponseEntity<>(HttpStatus.CONFLICT);
            case 404:
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            default:
                return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
        }
    }

    public ResponseEntity<Device> getDeviceById(
        @Parameter(in = ParameterIn.PATH, description = "The id that needs to be fetched. Use '1' for testing. ", required = true, schema = @Schema())
        @PathVariable("device_id") String deviceId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                Long id = Long.parseLong(deviceId);
            } catch (NumberFormatException e) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            if (deviceService.findDeviceByDeviceId(Long.parseLong(deviceId)).isPresent() &&
                SecurityUtils.isAdmin()) {
                Device device = deviceService.findDeviceByDeviceId(Long.parseLong(deviceId)).get();
                return new ResponseEntity<Device>(device, HttpStatus.OK);
            } else if (!SecurityUtils.isAdmin()) {
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            } else {
                return new ResponseEntity<Device>(HttpStatus.NOT_FOUND);
            }
        }
        return new ResponseEntity<Device>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<Device>> getDevices() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            if (!deviceService.findAll().isEmpty() && SecurityUtils.isAdmin()) {
                return new ResponseEntity<List<Device>>(deviceService.findAll(), HttpStatus.OK);
            } else if (!SecurityUtils.isAdmin()) {
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        }

        return new ResponseEntity<List<Device>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Device> updateDevice(
        @Parameter(in = ParameterIn.PATH, description = "device_id that need to be updated", required = true, schema = @Schema())
        @PathVariable("device_id") String deviceId,
        @Parameter(in = ParameterIn.DEFAULT, description = "Updated device object", required = true, schema = @Schema())
        @Valid @RequestBody Device body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            int result = deviceService.updateDevice(deviceId, body);
            switch (result) {
                case 200:
                    return new ResponseEntity<>(HttpStatus.OK);
                case 204:
                    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
                case 400:
                    return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
                case 401:
                    return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
                case 403:
                    return new ResponseEntity<>(HttpStatus.FORBIDDEN);
                case 404:
                    return new ResponseEntity<>(HttpStatus.NOT_FOUND);
                default:
                    return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
            }
        }

        return new ResponseEntity<Device>(HttpStatus.NOT_IMPLEMENTED);
    }

}
