package com.vision_aiot.services;

import com.vision_aiot.model.User;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

//@Service
public interface UserService {
    int addUser(User user);

    int deleteUser(String userUsername);

    Optional<User> findUserByUserUsername(String userUsername);

    int updateUser(String username, User user);

    int creatUsersWithListInput(List<User> users);
}
