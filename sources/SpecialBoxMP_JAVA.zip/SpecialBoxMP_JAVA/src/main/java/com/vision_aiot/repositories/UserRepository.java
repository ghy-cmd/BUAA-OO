package com.vision_aiot.repositories;

import com.vision_aiot.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findUserByUserUsername(String userUsername);

    Optional<User> findUserByUserEmail(String userEmail);

    Optional<User> findUserByUserPhone(String userPhone);

    void deleteUserByUserUsername(String userUsername);

    List<User> findAll();
}
