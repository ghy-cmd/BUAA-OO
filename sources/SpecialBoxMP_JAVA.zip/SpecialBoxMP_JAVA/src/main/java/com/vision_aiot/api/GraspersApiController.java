package com.vision_aiot.api;

import com.vision_aiot.model.Grasper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vision_aiot.security.SecurityUtils;
import com.vision_aiot.services.GrasperService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-25T11:34:31.971Z[GMT]")
@RestController
public class GraspersApiController implements GraspersApi {

    private static final Logger log = LoggerFactory.getLogger(GraspersApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    private GrasperService grasperService;

    @org.springframework.beans.factory.annotation.Autowired
    public GraspersApiController(ObjectMapper objectMapper, HttpServletRequest request,
                                 GrasperService grasperService) {
        this.objectMapper = objectMapper;
        this.request = request;
        this.grasperService = grasperService;
    }

    public ResponseEntity<Void> creatGrasper(
        @Parameter(in = ParameterIn.DEFAULT, description = "Created grasper object", required = true, schema = @Schema())
        @Valid @RequestBody Grasper body) {
        String accept = request.getHeader("Accept");
        int result = grasperService.creatGrasper(body);
        switch (result) {
            case 200:
                return new ResponseEntity<>(HttpStatus.OK);
            case 201:
                return new ResponseEntity<>(HttpStatus.CREATED);
            case 401:
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            case 404:
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            default:
                return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
        }
    }

    public ResponseEntity<Void> createGraspersWithListInput(
        @Parameter(in = ParameterIn.DEFAULT, description = "List of graspers object", required = true, schema = @Schema())
        @Valid @RequestBody List<Grasper> body) {
        String accept = request.getHeader("Accept");
        int result = grasperService.creatGrasperWithListInput(body);
        switch (result) {
            case 200:
                return new ResponseEntity<>(HttpStatus.OK);
            case 201:
                return new ResponseEntity<>(HttpStatus.CREATED);
            case 401:
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            case 404:
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            default:
                return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
        }
    }

    public ResponseEntity<Void> deleteGrasper(
        @Parameter(in = ParameterIn.PATH, description = "The name that needs to be deleted", required = true, schema = @Schema())
        @PathVariable("grasper_id") String grasperId) {
        String accept = request.getHeader("Accept");
        int result = grasperService.deleteGrasper(grasperId);
        switch (result) {
            case 200:
                return new ResponseEntity<>(HttpStatus.OK);
            case 204:
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            case 400:
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            case 401:
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            case 404:
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            default:
                return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
        }
    }

    public ResponseEntity<Grasper> getGrasperById(
        @Parameter(in = ParameterIn.PATH, description = "The id that needs to be fetched. Use '1' for testing. ", required = true, schema = @Schema())
        @PathVariable("grasper_id") String grasperId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {

            try {
                Long id = Long.parseLong(grasperId);
            } catch (NumberFormatException e) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            if (grasperService.findGrasperByGrasperId(Long.parseLong(grasperId)).isPresent() &&
                SecurityUtils.isAdmin()) {
                Grasper grasper =
                    grasperService.findGrasperByGrasperId(Long.parseLong(grasperId)).get();
                return new ResponseEntity<Grasper>(grasper, HttpStatus.OK);
            } else if (!SecurityUtils.isAdmin()) {
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            } else {
                return new ResponseEntity<Grasper>(HttpStatus.NOT_FOUND);
            }
        }
        return new ResponseEntity<Grasper>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<Grasper>> getGraspers() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            if (!grasperService.findAll().isEmpty() && SecurityUtils.isAdmin()) {
                return new ResponseEntity<List<Grasper>>(grasperService.findAll(), HttpStatus.OK);
            } else if (!SecurityUtils.isAdmin()) {
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        }

        return new ResponseEntity<List<Grasper>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> updateGrasper(
        @Parameter(in = ParameterIn.PATH, description = "grasper_id that need to be updated", required = true, schema = @Schema())
        @PathVariable("grasper_id") String grasperId,
        @Parameter(in = ParameterIn.DEFAULT, description = "Updated grasper object", required = true, schema = @Schema())
        @Valid @RequestBody Grasper body) {
        String accept = request.getHeader("Accept");
        int result = grasperService.updateGrasper(grasperId, body);
        switch (result) {
            case 200:
                return new ResponseEntity<>(HttpStatus.OK);
            case 204:
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            case 401:
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            case 404:
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            default:
                return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
        }
    }

}
