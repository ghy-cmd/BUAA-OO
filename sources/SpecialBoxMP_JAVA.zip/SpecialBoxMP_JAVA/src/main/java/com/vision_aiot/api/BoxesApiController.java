package com.vision_aiot.api;

import com.vision_aiot.api.exception.InvalidIdException;
import com.vision_aiot.api.exception.NoBoxException;
import com.vision_aiot.model.Box;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vision_aiot.services.BoxServiceImp;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import javax.annotation.Resource;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-15T02:47:00.719Z[GMT]")
@RestController
public class BoxesApiController implements BoxesApi {
    @Resource
    private BoxServiceImp boxservice;
    
    private static final Logger log = LoggerFactory.getLogger(BoxesApiController.class);
    
    private final ObjectMapper objectMapper;
    
    private final HttpServletRequest request;
    
    @org.springframework.beans.factory.annotation.Autowired
    public BoxesApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }
    
    public ResponseEntity<Void> createBox(@Parameter(in = ParameterIn.DEFAULT, description = "Created box object", required = true, schema = @Schema()) @Valid @RequestBody Box body) {
        String accept = request.getHeader("Accept");
        boxservice.createBox(body);
        //????????default
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }
    
    public ResponseEntity<Void> createBoxesWithArrayInput(@Parameter(in = ParameterIn.DEFAULT, description = "List of boxes object", required = true, schema = @Schema()) @Valid @RequestBody List<Box> body) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }
    
    public ResponseEntity<Void> createBoxesWithListInput(@Parameter(in = ParameterIn.DEFAULT, description = "List of boxes object", required = true, schema = @Schema()) @Valid @RequestBody List<Box> body) {
        String accept = request.getHeader("Accept");
        boxservice.createBoxesWithListInput(body);
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }
    
    public ResponseEntity<Void> deleteBox(@Parameter(in = ParameterIn.PATH, description = "The name that needs to be deleted", required = true, schema = @Schema()) @PathVariable("box_id") String boxId) {
        String accept = request.getHeader("Accept");
        try {
            boxservice.deleteBox(boxId);
        } catch (InvalidIdException e) {
            return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
        } catch (NoBoxException e) {
            return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Void>(HttpStatus.OK);
    }
    
    public ResponseEntity<Box> getBoxById(@Parameter(in = ParameterIn.PATH, description = "The id that needs to be fetched. Use '1' for testing. ", required = true, schema = @Schema()) @PathVariable("box_id") String boxId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                Box result = boxservice.getBoxByBoxId(boxId);
                String string = "{\n  \"box_id\" : " + result.getBoxId() + ",\n  \"box_height\" : " + result.getBoxHeight() + ",\n  \"box_name\" : " + result.getBoxName() + ",\n  \"box_width\" " + result.getBoxWidth() + ",\n  \"box_color\" : " + result.getBoxColor() + ",\n  \"box_length\" : " + result.getBoxLength() + "\n}";
                return new ResponseEntity<Box>(objectMapper.readValue(string, Box.class), HttpStatus.OK);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Box>(HttpStatus.INTERNAL_SERVER_ERROR);
            } catch (NoBoxException e) {
                return new ResponseEntity<Box>(HttpStatus.NOT_FOUND);
            } catch (InvalidIdException e) {
                return new ResponseEntity<Box>(HttpStatus.BAD_REQUEST);
            }
        }
        
        return new ResponseEntity<Box>(HttpStatus.BAD_REQUEST);
    }
    
    public ResponseEntity<List<Box>> getBoxes() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                List<Box> boxes = boxservice.getBoxes();
                String stringAll = "[ ";
                for (Box result : boxes) {
                    String string = "{\n  \"box_id\" : " + result.getBoxId() + ",\n  \"box_height\" : " + result.getBoxHeight() + ",\n  \"box_name\" : " + result.getBoxName() + ",\n  \"box_width\" " + result.getBoxWidth() + ",\n  \"box_color\" : " + result.getBoxColor() + ",\n  \"box_length\" : " + result.getBoxLength() + "\n}";
                    stringAll = stringAll + string;
                }
                stringAll = stringAll + " ]";
                return new ResponseEntity<List<Box>>(objectMapper.readValue(stringAll, List.class), HttpStatus.OK);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<Box>>(HttpStatus.INTERNAL_SERVER_ERROR);
            } catch (NoBoxException e) {
                return new ResponseEntity<List<Box>>(HttpStatus.NOT_FOUND);
            }
        }
        
        return new ResponseEntity<List<Box>>(HttpStatus.BAD_REQUEST);
    }
    
    public ResponseEntity<Void> updateBox(@Parameter(in = ParameterIn.PATH, description = "box_id that need to be updated", required = true, schema = @Schema()) @PathVariable("box_id") String boxId, @Parameter(in = ParameterIn.DEFAULT, description = "Updated box object", required = true, schema = @Schema()) @Valid @RequestBody Box body) {
        String accept = request.getHeader("Accept");
        try {
            boxservice.updateBox(boxId, body);
        } catch (InvalidIdException e) {
            return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
        } catch (NoBoxException e) {
            return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Void>(HttpStatus.OK);
    }
    
}

