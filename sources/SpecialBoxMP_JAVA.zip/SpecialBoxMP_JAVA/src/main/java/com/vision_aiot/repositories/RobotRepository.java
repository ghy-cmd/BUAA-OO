package com.vision_aiot.repositories;

import com.vision_aiot.model.Robot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RobotRepository extends JpaRepository<Robot, Long> {
    List<Robot> findAll();

    Optional<Robot> findRobotByRobotId(Long id);

    Optional<Robot> findRobotByRobotName(String robotName);

    void deleteRobotByRobotId(Long id);
}
