package com.vision_aiot.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Optional;

/**
 * SecurityUtils
 * 安全工具类
 */
public class SecurityUtils {
    private SecurityUtils() {
    }

    /**
     * @return Current user username
     */
    public static Optional<String> getCurrentUsername() {
        final Authentication authentication =
            SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null) {
            return Optional.empty();
        }

        String username = null;
        if (authentication.getPrincipal() instanceof UserDetails) {
            UserDetails springSecurityUser = (UserDetails) authentication.getPrincipal();
            username = springSecurityUser.getUsername();
        } else if (authentication.getPrincipal() instanceof String) {
            username = (String) authentication.getPrincipal();
        }

        return Optional.ofNullable(username);
    }

    /**
     * @return Current user authorities
     */
    public static Collection<? extends GrantedAuthority> getCurrentUserAuthorities() {
        final Authentication authentication =
            SecurityContextHolder.getContext().getAuthentication();
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        return authorities;
    }

    public static boolean isAdmin() {
        Collection<? extends GrantedAuthority> authorities =
            SecurityUtils.getCurrentUserAuthorities();

        boolean isAdmin = false;

        for (GrantedAuthority grantedAuthority : authorities) {
            if (grantedAuthority.getAuthority().equals("ROLE_ADMIN")) {
                isAdmin = true;
            }
        }
        return isAdmin;
    }
}