package com.vision_aiot.services;

import com.vision_aiot.model.Device;
import com.vision_aiot.model.Grasper;
import com.vision_aiot.model.Robot;
import com.vision_aiot.repositories.DeviceRepository;
import com.vision_aiot.repositories.GrasperRepository;
import com.vision_aiot.repositories.RobotRepository;
import com.vision_aiot.security.SecurityUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DeviceServiceImpl implements DeviceService {
    private final DeviceRepository deviceRepository;

    private final RobotRepository robotRepository;

    private final GrasperRepository grasperRepository;

    public DeviceServiceImpl(DeviceRepository deviceRepository, RobotRepository robotRepository,
                             GrasperRepository grasperRepository) {
        this.deviceRepository = deviceRepository;
        this.robotRepository = robotRepository;
        this.grasperRepository = grasperRepository;
    }

    @Override
    public int creatDevice(Device device) {
        boolean ispresent = deviceRepository.findDeviceByDeviceId(device.getDeviceId()).isPresent();
        try {
            boolean withoutConditionRobot = device.getRobot().getRobotId() == null &&
                device.getRobot().getRobotName() == null;
            boolean withoutConditionGrasper = device.getGrasper().getGrasperId() == null &&
                device.getGrasper().getGrasperName() == null;
        } catch (NumberFormatException e) {
            return 400;
        }

        boolean withoutConditionRobot = device.getRobot().getRobotId() == null &&
            device.getRobot().getRobotName() == null;
        boolean withoutConditionGrasper = device.getGrasper().getGrasperId() == null &&
            device.getGrasper().getGrasperName() == null;

        if (ispresent) {
            return 409;
        } else if (withoutConditionGrasper || withoutConditionRobot) {
            return 400;
        } else if (SecurityUtils.isAdmin()) {
            if (device.getRobot().getRobotId() != null &&
                robotRepository.findRobotByRobotId(device.getRobot().getRobotId()).isPresent()) {
                Robot robot =
                    robotRepository.findRobotByRobotId(device.getRobot().getRobotId()).get();
                device.setRobot(robot);
            } else if (device.getRobot().getRobotName() != null &&
                robotRepository.findRobotByRobotName(device.getRobot().getRobotName())
                    .isPresent()) {
                Robot robot =
                    robotRepository.findRobotByRobotName(device.getRobot().getRobotName()).get();
                device.setRobot(robot);
            } else {
                return 404;
            }
            if (device.getGrasper().getGrasperId() != null &&
                grasperRepository.findGrasperByGrasperId(device.getGrasper().getGrasperId())
                    .isPresent()) {
                Grasper grasper =
                    grasperRepository.findGrasperByGrasperId(device.getGrasper().getGrasperId())
                        .get();
                device.setGrasper(grasper);
            } else if (device.getGrasper().getGrasperName() != null &&
                grasperRepository.findGrasperByGrasperName(device.getGrasper().getGrasperName())
                    .isPresent()) {
                Grasper grasper =
                    grasperRepository.findGrasperByGrasperName(device.getGrasper().getGrasperName())
                        .get();
                device.setGrasper(grasper);
            } else {
                return 404;
            }
            deviceRepository.save(device);
            return 201;
        } else {
            return 403;
        }
    }

    @Override
    public int creatDeviceWithListInput(List<Device> devices) {
        boolean isPresent = false;
        boolean withoutConditionRobot = false;
        boolean withoutConditionGrasper = false;
        for (Device device : devices) {
            if (deviceRepository.findDeviceByDeviceId(device.getDeviceId()).isPresent()) {
                isPresent = true;
                break;
            }
            try {
                withoutConditionRobot = device.getRobot().getRobotId() == null &&
                    device.getRobot().getRobotName() == null;
                withoutConditionGrasper = device.getGrasper().getGrasperId() == null &&
                    device.getGrasper().getGrasperName() == null;
            } catch (NumberFormatException e) {
                return 400;
            }
            withoutConditionRobot = device.getRobot().getRobotId() == null &&
                device.getRobot().getRobotName() == null;
            withoutConditionGrasper = device.getGrasper().getGrasperId() == null &&
                device.getGrasper().getGrasperName() == null;
            if (device.getRobot().getRobotId() != null &&
                robotRepository.findRobotByRobotId(device.getRobot().getRobotId()).isPresent()) {
                Robot robot =
                    robotRepository.findRobotByRobotId(device.getRobot().getRobotId()).get();
                device.setRobot(robot);
            } else if (device.getRobot().getRobotName() != null &&
                robotRepository.findRobotByRobotName(device.getRobot().getRobotName())
                    .isPresent()) {
                Robot robot =
                    robotRepository.findRobotByRobotName(device.getRobot().getRobotName()).get();
                device.setRobot(robot);
            } else {
                return 404;
            }
            if (device.getGrasper().getGrasperId() != null &&
                grasperRepository.findGrasperByGrasperId(device.getGrasper().getGrasperId())
                    .isPresent()) {
                Grasper grasper =
                    grasperRepository.findGrasperByGrasperId(device.getGrasper().getGrasperId())
                        .get();
                device.setGrasper(grasper);
            } else if (device.getGrasper().getGrasperName() != null &&
                grasperRepository.findGrasperByGrasperName(device.getGrasper().getGrasperName())
                    .isPresent()) {
                Grasper grasper =
                    grasperRepository.findGrasperByGrasperName(device.getGrasper().getGrasperName())
                        .get();
                device.setGrasper(grasper);
            } else {
                return 404;
            }
        }
        if (isPresent) {
            return 409;
        } else if (withoutConditionGrasper || withoutConditionRobot) {
            return 400;
        } else if (SecurityUtils.isAdmin()) {
            for (Device device : devices) {
                deviceRepository.save(device);
            }
            return 201;
        } else {
            return 403;
        }
    }

    @Override
    public int deleteDevice(String deviceId) {
        try {
            Long id = Long.parseLong(deviceId);
        } catch (NumberFormatException e) {
            return 400;
        }

        if (deviceRepository.findDeviceByDeviceId(Long.parseLong(deviceId)).isPresent() &&
            SecurityUtils.isAdmin()) {
            deviceRepository.deleteDeviceByDeviceId(Long.parseLong(deviceId));
            return 200;
        } else if (robotRepository.findAll().isEmpty()) {
            return 204;
        } else if (!SecurityUtils.isAdmin()) {
            return 403;
        } else {
            return 404;
        }
    }

    @Override
    public Optional<Device> findDeviceByDeviceId(Long deviceId) {
        return deviceRepository.findDeviceByDeviceId(deviceId);
    }

    @Override
    public List<Device> findAll() {
        return deviceRepository.findAll();
    }

    @Override
    public int updateDevice(String deviceId, Device device) {
        try {
            Long id = Long.parseLong(deviceId);
        } catch (NumberFormatException e) {
            return 400;
        }
        try {
            boolean withoutConditionRobot = device.getRobot().getRobotId() == null &&
                device.getRobot().getRobotName() == null;
            boolean withoutConditionGrasper = device.getGrasper().getGrasperId() == null &&
                device.getGrasper().getGrasperName() == null;
        } catch (NumberFormatException e) {
            return 400;
        }

        boolean withoutConditionRobot = device.getRobot().getRobotId() == null &&
            device.getRobot().getRobotName() == null;
        boolean withoutConditionGrasper = device.getGrasper().getGrasperId() == null &&
            device.getGrasper().getGrasperName() == null;
        if (deviceRepository.findDeviceByDeviceId(Long.parseLong(deviceId)).isPresent() &&
            SecurityUtils.isAdmin()) {
            if (withoutConditionGrasper || withoutConditionRobot) {
                return 400;
            } else {
                if (device.getRobot().getRobotId() != null &&
                    robotRepository.findRobotByRobotId(device.getRobot().getRobotId())
                        .isPresent()) {
                    Robot robot =
                        robotRepository.findRobotByRobotId(device.getRobot().getRobotId()).get();
                    device.setRobot(robot);
                } else if (device.getRobot().getRobotName() != null &&
                    robotRepository.findRobotByRobotName(device.getRobot().getRobotName())
                        .isPresent()) {
                    Robot robot =
                        robotRepository.findRobotByRobotName(device.getRobot().getRobotName())
                            .get();
                    device.setRobot(robot);
                } else {
                    return 404;
                }
                if (device.getGrasper().getGrasperId() != null &&
                    grasperRepository.findGrasperByGrasperId(device.getGrasper().getGrasperId())
                        .isPresent()) {
                    Grasper grasper =
                        grasperRepository.findGrasperByGrasperId(device.getGrasper().getGrasperId())
                            .get();
                    device.setGrasper(grasper);
                } else if (device.getGrasper().getGrasperName() != null &&
                    grasperRepository.findGrasperByGrasperName(device.getGrasper().getGrasperName())
                        .isPresent()) {
                    Grasper grasper =
                        grasperRepository
                            .findGrasperByGrasperName(device.getGrasper().getGrasperName())
                            .get();
                    device.setGrasper(grasper);
                } else {
                    return 404;
                }
                deleteDevice(deviceId);
                deviceRepository.save(device);
                return 200;
            }
        } else if (robotRepository.findAll().isEmpty()) {
            return 204;
        } else if (!SecurityUtils.isAdmin()) {
            return 403;
        } else {
            return 404;
        }
    }
}
