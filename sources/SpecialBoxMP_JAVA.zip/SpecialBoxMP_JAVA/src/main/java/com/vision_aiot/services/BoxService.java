package com.vision_aiot.services;

import com.vision_aiot.api.exception.NoBoxException;
import com.vision_aiot.model.Box;

import java.util.List;

public interface BoxService {
    Box createBox(Box box);
    
    List<Box> getBoxes() throws NoBoxException;
    
    List<Box> createBoxesWithListInput(List<Box> boxes);
    
    void deleteBox(String box_id);
    
    Box getBoxByBoxId(String box_id);
    
    void updateBox(String box_id, Box box);
}