package com.vision_aiot;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import springfox.documentation.oas.annotations.EnableOpenApi;

@SpringBootApplication
@EnableOpenApi
@ComponentScan(basePackages = { "com.vision_aiot", "com.vision_aiot.api" , "com.vision_aiot.configuration", "com.vision_aiot.services"})
public class SpecialBoxManagePlatformSpringBoot implements CommandLineRunner {
    
    @Override
    public void run(String... arg0) throws Exception {
        if (arg0.length > 0 && arg0[0].equals("exitcode")) {
            throw new ExitException();
        }
    }
    
    public static void main(String[] args) throws Exception {
        new SpringApplication(SpecialBoxManagePlatformSpringBoot.class).run(args);
    }
    
    class ExitException extends RuntimeException implements ExitCodeGenerator {
        private static final long serialVersionUID = 1L;
        
        @Override
        public int getExitCode() {
            return 10;
        }
        
    }
}
