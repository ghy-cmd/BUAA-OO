package com.vision_aiot.services;

import com.vision_aiot.api.NotFoundException;
import com.vision_aiot.api.exception.NoBoxException;
import com.vision_aiot.model.User;
import com.vision_aiot.repositories.UserRepository;
import com.vision_aiot.security.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public int addUser(User user) {
        Collection<? extends GrantedAuthority> authorities =
            SecurityUtils.getCurrentUserAuthorities();

        boolean isAdmin = false;

        for (GrantedAuthority grantedAuthority : authorities) {
            if (grantedAuthority.getAuthority().equals("ROLE_ADMIN")) {
                isAdmin = true;
            }
        }
        boolean isPresent =
            userRepository.findUserByUserUsername(user.getUserUsername()).isPresent() ||
                userRepository.findUserByUserEmail(user.getUserEmail()).isPresent() ||
                userRepository.findUserByUserPhone(user.getUserPhone()).isPresent();
        if (isPresent) {
            return 201;
        } else if (isAdmin) {
            userRepository.save(user);
            return 200;
        } else {
            return 401;
        }
    }

    @Override
    public int creatUsersWithListInput(List<User> users) {
        String currentUsername = "";
        if (SecurityUtils.getCurrentUsername().isPresent()) {
            currentUsername = SecurityUtils.getCurrentUsername().get();
        }
        Collection<? extends GrantedAuthority> authorities =
            SecurityUtils.getCurrentUserAuthorities();

        boolean isAdmin = false;

        for (GrantedAuthority grantedAuthority : authorities) {
            if (grantedAuthority.getAuthority().equals("ROLE_ADMIN")) {
                isAdmin = true;
            }
        }
        boolean isPresent = false;
        for (User user : users) {
            if (userRepository.findUserByUserUsername(user.getUserUsername()).isPresent() ||
                userRepository.findUserByUserEmail(user.getUserEmail()).isPresent() ||
                userRepository.findUserByUserPhone(user.getUserPhone()).isPresent()) {
                isPresent = true;
                break;
            }
        }
        if (isPresent) {
            return 201;
        } else if (isAdmin) {
            for (User user : users) {
                userRepository.save(user);
            }
            return 200;
        } else {
            return 401;
        }
    }

    @Override
    public int deleteUser(String username) {
        String currentUsername = "";
        if (SecurityUtils.getCurrentUsername().isPresent()) {
            currentUsername = SecurityUtils.getCurrentUsername().get();
        }

        Collection<? extends GrantedAuthority> authorities =
            SecurityUtils.getCurrentUserAuthorities();

        boolean isAdmin = false;

        for (GrantedAuthority grantedAuthority : authorities) {
            if (grantedAuthority.getAuthority().equals("ROLE_ADMIN")) {
                isAdmin = true;
            }
        }

        if (findUserByUserUsername(username).isPresent() &&
            (currentUsername.equals(username) || isAdmin)) {
            userRepository.deleteUserByUserUsername(username);
            return 200;
        } else if (userRepository.findAll().isEmpty()) {
            return 204;
        } else if (!(currentUsername.equals(username) || isAdmin)) {
            return 401;
        } else {
            return 404;
        }
    }

    @Override
    public Optional<User> findUserByUserUsername(String userUsername) {
//        if (userRepository.findUserByUserUsername(userUsername) == null) {
//            return null;
//        } else {
//            return userRepository.findUserByUserUsername(userUsername).get();
//        }
        return userRepository.findUserByUserUsername(userUsername);
    }

    @Override
    public int updateUser(String username, User user) {
//        userRepository.delete(userRepository.findUserByUserUsername(username).get());
//        userRepository.save(user);
        String currentUsername = "";
        if (SecurityUtils.getCurrentUsername().isPresent()) {
            currentUsername = SecurityUtils.getCurrentUsername().get();
        }

        Collection<? extends GrantedAuthority> authorities =
            SecurityUtils.getCurrentUserAuthorities();

        boolean isAdmin = false;

        for (GrantedAuthority grantedAuthority : authorities) {
            if (grantedAuthority.getAuthority().equals("ROLE_ADMIN")) {
                isAdmin = true;
            }
        }

        if (userRepository.findUserByUserUsername(username).isPresent() &&
            (currentUsername.equals(username) || isAdmin)) {
            userRepository.deleteUserByUserUsername(username);
            userRepository.save(user);
            return 200;
        } else if (!(currentUsername.equals(username) || isAdmin)) {
            return 401;
        } else {
            return 404;
        }
    }
}

