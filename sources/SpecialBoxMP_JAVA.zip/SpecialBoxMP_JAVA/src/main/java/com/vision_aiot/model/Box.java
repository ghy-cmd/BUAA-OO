package com.vision_aiot.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Box
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-15T02:47:00.719Z[GMT]")

@Entity
@Table(name = "t_Box")
public class Box {
    @Id
    @SequenceGenerator(sequenceName = "box_seqg", name = "box_seqg", allocationSize = 1, initialValue = 10000001)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "box_seqg")
    @JsonProperty("box_id")
    @Column(name = "box_id", nullable = false)
    private Long boxId = null;
    
    @Column(name = "box_name", length = 255, nullable = false)
    @JsonProperty("box_name")
    private String boxName = null;
    
    @Column(name = "box_color", nullable = false)
    @JsonProperty("box_color")
    private Integer boxColor = null;
    
    @Column(name = "box_length", nullable = false)
    @JsonProperty("box_length")
    private Double boxLength = null;
    
    @Column(name = "box_width", nullable = false)
    @JsonProperty("box_width")
    private Double boxWidth = null;
    
    @Column(name = "box_height", nullable = false)
    @JsonProperty("box_height")
    private Double boxHeight = null;
    
    @Column(name = "username", nullable = false)
    @JsonProperty("username")
    private String username = null;
    
    public Box boxId(Long boxId) {
        this.boxId = boxId;
        return this;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getUsername() {
        return username;
    }
    
    /**
     * Get boxId
     *
     * @return boxId
     **/
    @Schema(description = "")
    
    public Long getBoxId() {
        return boxId;
    }
    
    public void setBoxId(Long boxId) {
        this.boxId = boxId;
    }
    
    public Box boxName(String boxName) {
        this.boxName = boxName;
        return this;
    }
    
    /**
     * Get boxName
     *
     * @return boxName
     **/
    @Schema(description = "")
    
    public String getBoxName() {
        return boxName;
    }
    
    public void setBoxName(String boxName) {
        this.boxName = boxName;
    }
    
    public Box boxColor(Integer boxColor) {
        this.boxColor = boxColor;
        return this;
    }
    
    /**
     * Get boxColor
     *
     * @return boxColor
     **/
    @Schema(description = "")
    
    public Integer getBoxColor() {
        return boxColor;
    }
    
    public void setBoxColor(Integer boxColor) {
        this.boxColor = boxColor;
    }
    
    public Box boxLength(Double boxLength) {
        this.boxLength = boxLength;
        return this;
    }
    
    /**
     * Get boxLength
     *
     * @return boxLength
     **/
    @Schema(description = "")
    
    public Double getBoxLength() {
        return boxLength;
    }
    
    public void setBoxLength(Double boxLength) {
        this.boxLength = boxLength;
    }
    
    public Box boxWidth(Double boxWidth) {
        this.boxWidth = boxWidth;
        return this;
    }
    
    /**
     * Get boxWidth
     *
     * @return boxWidth
     **/
    @Schema(description = "")
    
    public Double getBoxWidth() {
        return boxWidth;
    }
    
    public void setBoxWidth(Double boxWidth) {
        this.boxWidth = boxWidth;
    }
    
    public Box boxHeight(Double boxHeight) {
        this.boxHeight = boxHeight;
        return this;
    }
    
    /**
     * Get boxHeight
     *
     * @return boxHeight
     **/
    @Schema(description = "")
    
    public Double getBoxHeight() {
        return boxHeight;
    }
    
    public void setBoxHeight(Double boxHeight) {
        this.boxHeight = boxHeight;
    }
    
    
    @Override
    public boolean equals(java.lang.Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Box box = (Box) o;
        return Objects.equals(this.boxId, box.boxId) &&
                Objects.equals(this.boxName, box.boxName) &&
                Objects.equals(this.boxColor, box.boxColor) &&
                Objects.equals(this.boxLength, box.boxLength) &&
                Objects.equals(this.boxWidth, box.boxWidth) &&
                Objects.equals(this.boxHeight, box.boxHeight);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(boxId, boxName, boxColor, boxLength, boxWidth, boxHeight);
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Box {\n");
        
        sb.append("    boxId: ").append(toIndentedString(boxId)).append("\n");
        sb.append("    boxName: ").append(toIndentedString(boxName)).append("\n");
        sb.append("    boxColor: ").append(toIndentedString(boxColor)).append("\n");
        sb.append("    boxLength: ").append(toIndentedString(boxLength)).append("\n");
        sb.append("    boxWidth: ").append(toIndentedString(boxWidth)).append("\n");
        sb.append("    boxHeight: ").append(toIndentedString(boxHeight)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(java.lang.Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}
