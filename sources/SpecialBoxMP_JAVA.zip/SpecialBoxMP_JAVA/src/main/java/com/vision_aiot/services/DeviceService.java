package com.vision_aiot.services;

import com.vision_aiot.model.Device;

import java.util.List;
import java.util.Optional;

public interface DeviceService {
    int creatDevice(Device device);

    int creatDeviceWithListInput(List<Device> devices);

    int deleteDevice(String deviceId);

    Optional<Device> findDeviceByDeviceId(Long deviceId);

    List<Device> findAll();

    int updateDevice(String deviceId, Device device);
}
