package com.vision_aiot.model;

import java.io.Serializable;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Grasper
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-25T11:34:31.971Z[GMT]")

@Entity
@Table(name = "t_grasper")
public class Grasper implements Serializable {

    @Id
    @SequenceGenerator(sequenceName = "grasper_seqg", name = "grasper_seqg", allocationSize = 1, initialValue = 1000)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "grasper_seqg")
    @JsonProperty("grasper_id")
    @Column(name = "grasper_id", nullable = false, unique = true)
    private Long grasperId = null;

    @Column(name = "grasper_name", length = 255, nullable = false, unique = true)
    @JsonProperty("grasper_name")
    private String grasperName = null;

    @Column(name = "grasper_company", nullable = false)
    @JsonProperty("grasper_company")
    private String grasperCompany = null;

    public Grasper grasperId(Long grasperId) {
        this.grasperId = grasperId;
        return this;
    }

    /**
     * Get grasperId
     *
     * @return grasperId
     **/
    @Schema(description = "")

    public Long getGrasperId() {
        return grasperId;
    }

    public void setGrasperId(Long grasperId) {
        this.grasperId = grasperId;
    }

    public Grasper grasperName(String grasperName) {
        this.grasperName = grasperName;
        return this;
    }

    /**
     * Get grasperName
     *
     * @return grasperName
     **/
    @Schema(description = "")

    public String getGrasperName() {
        return grasperName;
    }

    public void setGrasperName(String grasperName) {
        this.grasperName = grasperName;
    }

    public Grasper grasperCompany(String grasperCompany) {
        this.grasperCompany = grasperCompany;
        return this;
    }

    /**
     * Get grasperCompany
     *
     * @return grasperCompany
     **/
    @Schema(description = "")

    public String getGrasperCompany() {
        return grasperCompany;
    }

    public void setGrasperCompany(String grasperCompany) {
        this.grasperCompany = grasperCompany;
    }


    @Override
    public boolean equals(java.lang.Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Grasper grasper = (Grasper) o;
        return Objects.equals(this.grasperId, grasper.grasperId) &&
            Objects.equals(this.grasperName, grasper.grasperName) &&
            Objects.equals(this.grasperCompany, grasper.grasperCompany);
    }

    @Override
    public int hashCode() {
        return Objects.hash(grasperId, grasperName, grasperCompany);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Grasper {\n");

        sb.append("    grasperId: ").append(toIndentedString(grasperId)).append("\n");
        sb.append("    grasperName: ").append(toIndentedString(grasperName)).append("\n");
        sb.append("    grasperCompany: ").append(toIndentedString(grasperCompany)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(java.lang.Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}
