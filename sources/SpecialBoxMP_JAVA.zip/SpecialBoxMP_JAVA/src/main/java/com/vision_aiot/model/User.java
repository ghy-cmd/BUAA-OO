package com.vision_aiot.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * User
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-02-26T01:16:47.041Z[GMT]")


@Entity
@Table(name = "t_user")
public class User implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Id
    @SequenceGenerator(sequenceName = "user_seqg", name = "user_seqg", allocationSize = 1, initialValue = 10000001)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_seqg")
    @JsonProperty("user_id")
    @Column(name = "user_id")
    private Long userId = null;
    
    @Column(length = 50, unique = true, nullable = false)
    @JsonProperty("user_username")
    private String userUsername = null;
    
    @Column(length = 140, nullable = false)
    @JsonProperty("user_password")
    private String userPassword = null;
    
    @Column
    @JsonProperty("user_name")
    private String userName = null;
    
    @Column(nullable = false)
    @JsonProperty("user_status")
    private Integer userStatus = null;
    
    @Column(unique = true)
    @JsonProperty("user_email")
    private String userEmail = null;
    
    @Column(length = 20, unique = true)
    @JsonProperty("user_phone")
    private String userPhone = null;
    
    @Column(length = 20)
    @JsonProperty("user_telephone")
    private String userTelephone = null;
    
    @ManyToMany(targetEntity = Role.class)
    @JoinTable(name = "t_user_role", joinColumns = {@JoinColumn(name = "uid", referencedColumnName = "user_id")},
            inverseJoinColumns = {@JoinColumn(name = "rid", referencedColumnName = "role_id")})
    private Set<Role> roles = new HashSet<>();
    
    public Set<Role> getRoles() {
        return roles;
    }
    
    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }
    
    public User userId(Long userId) {
        this.userId = userId;
        return this;
    }
    
    public User() {
    }
    
    public User(String userName, String userPassword) {
        this.userUsername = userName;
        this.userPassword = userPassword;
    }
    
    /**
     * Get userId
     *
     * @return userId
     **/
    @Schema(description = "")
    
    public Long getUserId() {
        return userId;
    }
    
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    
    public User userUsername(String userUsername) {
        this.userUsername = userUsername;
        return this;
    }
    
    /**
     * Get userUsername
     *
     * @return userUsername
     **/
    @Schema(description = "")
    
    public String getUserUsername() {
        return userUsername;
    }
    
    public void setUserUsername(String userUsername) {
        this.userUsername = userUsername;
    }
    
    public User userPassword(String userPassword) {
        this.userPassword = userPassword;
        return this;
    }
    
    /**
     * Get userPassword
     *
     * @return userPassword
     **/
    @Schema(description = "")
    
    public String getUserPassword() {
        return userPassword;
    }
    
    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }
    
    public User userName(String userName) {
        this.userName = userName;
        return this;
    }
    
    /**
     * Get userName
     *
     * @return userName
     **/
    @Schema(description = "")
    
    public String getUserName() {
        return userName;
    }
    
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    public User userStatus(Integer userStatus) {
        this.userStatus = userStatus;
        return this;
    }
    
    /**
     * Get userStatus
     *
     * @return userStatus
     **/
    @Schema(description = "")
    
    public Integer getUserStatus() {
        return userStatus;
    }
    
    public void setUserStatus(Integer userStatus) {
        this.userStatus = userStatus;
    }
    
    public User userEmail(String userEmail) {
        this.userEmail = userEmail;
        return this;
    }
    
    /**
     * Get userEmail
     *
     * @return userEmail
     **/
    @Schema(description = "")
    
    public String getUserEmail() {
        return userEmail;
    }
    
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
    
    public User userPhone(String userPhone) {
        this.userPhone = userPhone;
        return this;
    }
    
    /**
     * Get userPhone
     *
     * @return userPhone
     **/
    @Schema(description = "")
    
    public String getUserPhone() {
        return userPhone;
    }
    
    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }
    
    public User userTelephone(String userTelephone) {
        this.userTelephone = userTelephone;
        return this;
    }
    
    /**
     * Get userTelephone
     *
     * @return userTelephone
     **/
    @Schema(description = "")
    
    public String getUserTelephone() {
        return userTelephone;
    }
    
    public void setUserTelephone(String userTelephone) {
        this.userTelephone = userTelephone;
    }
    
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        User user = (User) o;
        return Objects.equals(this.userId, user.userId) &&
                Objects.equals(this.userUsername, user.userUsername) &&
                Objects.equals(this.userPassword, user.userPassword) &&
                Objects.equals(this.userName, user.userName) &&
                Objects.equals(this.userStatus, user.userStatus) &&
                Objects.equals(this.userEmail, user.userEmail) &&
                Objects.equals(this.userPhone, user.userPhone) &&
                Objects.equals(this.userTelephone, user.userTelephone);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(userId, userUsername, userPassword, userName, userStatus, userEmail, userPhone, userTelephone);
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class User {\n");
        
        sb.append("    userId: ").append(toIndentedString(userId)).append("\n");
        sb.append("    userUsername: ").append(toIndentedString(userUsername)).append("\n");
        sb.append("    userPassword: ").append(toIndentedString(userPassword)).append("\n");
        sb.append("    userName: ").append(toIndentedString(userName)).append("\n");
        sb.append("    userStatus: ").append(toIndentedString(userStatus)).append("\n");
        sb.append("    userEmail: ").append(toIndentedString(userEmail)).append("\n");
        sb.append("    userPhone: ").append(toIndentedString(userPhone)).append("\n");
        sb.append("    userTelephone: ").append(toIndentedString(userTelephone)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}
