package com.vision_aiot.api;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-02-26T01:16:47.041Z[GMT]")
public class NotFoundException extends ApiException {
    private int code;

    public NotFoundException(String msg, int code) {
        super(code, msg);
        this.code = code;
    }
}
