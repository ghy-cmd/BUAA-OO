package com.vision_aiot.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "t_role")
public class Role {
    private static final long serialVersionUID = 1L;
    
    @Id
    @SequenceGenerator(sequenceName = "role_seqg", name = "role_seqg", allocationSize = 1, initialValue = 4)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "role_seqg")
    @JsonProperty("role_id")
    @Column(name = "role_id")
    private Long roleId;
    
    @Column(name = "role_name", length = 50, unique = true)
    @JsonProperty("role_name")
    private String roleName;
    
    @ManyToMany(targetEntity = User.class)
    @JoinTable(name = "t_user_role",
            joinColumns = {@JoinColumn(name = "rid", referencedColumnName = "role_id")},
            inverseJoinColumns = {@JoinColumn(name = "uid", referencedColumnName = "user_id")})
    private Set<User> users = new HashSet<>();
    
    public Long getRoleId() {
        return roleId;
    }
    
    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }
    
    public String getRoleName() {
        return roleName;
    }
    
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
    
    public Set<User> getUsers() {
        return users;
    }
    
    public void setUsers(Set<User> users) {
        this.users = users;
    }
}
