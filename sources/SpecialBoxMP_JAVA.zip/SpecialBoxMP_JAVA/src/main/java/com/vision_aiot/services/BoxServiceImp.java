package com.vision_aiot.services;

import com.vision_aiot.api.exception.InvalidIdException;
import com.vision_aiot.api.exception.NoBoxException;
import com.vision_aiot.model.Box;
import com.vision_aiot.repositories.BoxRepository;
import com.vision_aiot.security.SecurityUtils;
import com.vision_aiot.services.BoxService;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Service("boxSerivce")
public class BoxServiceImp implements BoxService {
    @Resource
    private BoxRepository boxRepository;
    
    @Override
    public Box createBox(Box box) {
        boxRepository.save(box);
        return box;
    }
    
    @Override
    public List<Box> getBoxes() throws NoBoxException {
        Collection authorities = SecurityUtils.getCurrentUserAuthorities();
        String currentUsername = SecurityUtils.getCurrentUsername().get();
        boolean isAdmin = false;
        for (Object authority : authorities) {
            GrantedAuthority grantedAuthority = (GrantedAuthority) authority;
            if (grantedAuthority.getAuthority().equals("ROLE_ADMIN")) {
                isAdmin = true;
                break;
            }
        }
        if (isAdmin) {
            List<Box> result = boxRepository.findAll();
            if (result.isEmpty()) {
                throw new NoBoxException();
            } else {
                return result;
            }
        } else {
            List<Box> result = boxRepository.findByUsername(currentUsername);
            if (result.isEmpty()) {
                throw new NoBoxException();
            } else {
                return result;
            }
        }
    }
    
    @Override
    public List<Box> createBoxesWithListInput(List<Box> boxes) {
        for (Box box : boxes) {
            boxRepository.save(box);
        }
        return boxes;
    }
    
    @Override
    public void deleteBox(String box_id) {
        try {
            Long id = Long.parseLong(box_id);
        } catch (NumberFormatException e) {
            throw new InvalidIdException();
        }
        Collection authorities = SecurityUtils.getCurrentUserAuthorities();
        String currentUsername = SecurityUtils.getCurrentUsername().get();
        List<Box> boxes = boxRepository.findByUsername(currentUsername);
        if (boxes.isEmpty()) {
            throw new NoBoxException();
        } else {
            Box result = null;
            for (Box box : boxes) {
                if (box.getBoxId() == Long.parseLong(box_id)) {
                    result = box;
                    break;
                }
            }
            if (result == null) {
                throw new NoBoxException();
            } else {
                boxRepository.delete(result);
            }
        }
    }
    
    
    @Override
    public Box getBoxByBoxId(String box_id) {
        try {
            Long id = Long.parseLong(box_id);
        } catch (NumberFormatException e) {
            throw new InvalidIdException();
        }
        Optional<Box> result = null;
        result = boxRepository.findById(Long.parseLong(box_id));
        if (result == null) {
            throw new NoBoxException();
        }
        return result.get();
    }
    
    
    @Override
    public void updateBox(String box_id, Box box) {
        try {
            Long id = Long.parseLong(box_id);
        } catch (NumberFormatException e) {
            throw new InvalidIdException();
        }
        Optional<Box> result = null;
        result = boxRepository.findById(Long.parseLong(box_id));
        if (result == null) {
            throw new NoBoxException();
        }
        //update
        boxRepository.delete(result.get());
        boxRepository.save(box);
    }
}
