package com.vision_aiot.model;

import java.io.Serializable;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Robot
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-25T02:14:55.291Z[GMT]")

@Entity
@Table(name = "t_robot")
public class Robot implements Serializable {

    @Id
    @SequenceGenerator(sequenceName = "robot_seqg", name = "robot_seqg", allocationSize = 1, initialValue = 1000)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "robot_seqg")
    @JsonProperty("robot_id")
    @Column(name = "robot_id", nullable = false, unique = true)
    private Long robotId = null;

    @Column(name = "robot_name", length = 255, nullable = false, unique = true)
    @JsonProperty("robot_name")
    private String robotName = null;

    @Column(name = "robot_company", nullable = false)
    @JsonProperty("robot_company")
    private String robotCompany = null;

    @Column(name = "robot_axes", nullable = false)
    @JsonProperty("robot_axes")
    private Integer robotAxes = null;

    @Column(name = "robot_arm_length", nullable = false)
    @JsonProperty("robot_arm_length")
    private Double robotArmLength = null;

    @Column(name = "robot_reach", nullable = false)
    @JsonProperty("robot_reach")
    private Double robotReach = null;

    @Column(name = "robot_load_weight", nullable = false)
    @JsonProperty("robot_load_weight")
    private Double robotLoadWeight = null;

    @Column(name = "robot_mass", nullable = false)
    @JsonProperty("robot_mass")
    private Double robotMass = null;

    @Column(name = "robot_repeatability", nullable = false)
    @JsonProperty("robot_repeatability")
    private Boolean robotRepeatability = null;

    public Robot robotId(Long robotId) {
        this.robotId = robotId;
        return this;
    }

    /**
     * Get robotId
     *
     * @return robotId
     **/
    @Schema(description = "")

    public Long getRobotId() {
        return robotId;
    }

    public void setRobotId(Long robotId) {
        this.robotId = robotId;
    }

    public Robot ronotName(String ronotName) {
        this.robotName = ronotName;
        return this;
    }

    /**
     * Get ronotName
     *
     * @return ronotName
     **/
    @Schema(description = "")

    public String getRobotName() {
        return robotName;
    }

    public void setRobotName(String ronotName) {
        this.robotName = ronotName;
    }

    public Robot robotCompany(String robotCompany) {
        this.robotCompany = robotCompany;
        return this;
    }

    /**
     * Get robotCompany
     *
     * @return robotCompany
     **/
    @Schema(description = "")

    public String getRobotCompany() {
        return robotCompany;
    }

    public void setRobotCompany(String robotCompany) {
        this.robotCompany = robotCompany;
    }

    public Robot robotAxes(Integer robotAxes) {
        this.robotAxes = robotAxes;
        return this;
    }

    /**
     * Get robotAxes
     *
     * @return robotAxes
     **/
    @Schema(description = "")

    public Integer getRobotAxes() {
        return robotAxes;
    }

    public void setRobotAxes(Integer robotAxes) {
        this.robotAxes = robotAxes;
    }

    public Robot robotArmLength(Double robotArmLength) {
        this.robotArmLength = robotArmLength;
        return this;
    }

    /**
     * Get robotArmLength
     *
     * @return robotArmLength
     **/
    @Schema(description = "")

    public Double getRobotArmLength() {
        return robotArmLength;
    }

    public void setRobotArmLength(Double robotArmLength) {
        this.robotArmLength = robotArmLength;
    }

    public Robot robotReach(Double robotReach) {
        this.robotReach = robotReach;
        return this;
    }

    /**
     * Get robotReach
     *
     * @return robotReach
     **/
    @Schema(description = "")

    public Double getRobotReach() {
        return robotReach;
    }

    public void setRobotReach(Double robotReach) {
        this.robotReach = robotReach;
    }

    public Robot robotLoadWeight(Double robotLoadWeight) {
        this.robotLoadWeight = robotLoadWeight;
        return this;
    }

    /**
     * Get robotLoadWeight
     *
     * @return robotLoadWeight
     **/
    @Schema(description = "")

    public Double getRobotLoadWeight() {
        return robotLoadWeight;
    }

    public void setRobotLoadWeight(Double robotLoadWeight) {
        this.robotLoadWeight = robotLoadWeight;
    }

    public Robot robotMass(Double robotMass) {
        this.robotMass = robotMass;
        return this;
    }

    /**
     * Get robotMass
     *
     * @return robotMass
     **/
    @Schema(description = "")

    public Double getRobotMass() {
        return robotMass;
    }

    public void setRobotMass(Double robotMass) {
        this.robotMass = robotMass;
    }

    public Robot robotRepeatability(Boolean robotRepeatability) {
        this.robotRepeatability = robotRepeatability;
        return this;
    }

    /**
     * Get robotRepeatability
     *
     * @return robotRepeatability
     **/
    @Schema(description = "")

    public Boolean isRobotRepeatability() {
        return robotRepeatability;
    }

    public void setRobotRepeatability(Boolean robotRepeatability) {
        this.robotRepeatability = robotRepeatability;
    }


    @Override
    public boolean equals(java.lang.Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Robot robot = (Robot) o;
        return Objects.equals(this.robotId, robot.robotId) &&
            Objects.equals(this.robotName, robot.robotName) &&
            Objects.equals(this.robotCompany, robot.robotCompany) &&
            Objects.equals(this.robotAxes, robot.robotAxes) &&
            Objects.equals(this.robotArmLength, robot.robotArmLength) &&
            Objects.equals(this.robotReach, robot.robotReach) &&
            Objects.equals(this.robotLoadWeight, robot.robotLoadWeight) &&
            Objects.equals(this.robotMass, robot.robotMass) &&
            Objects.equals(this.robotRepeatability, robot.robotRepeatability);
    }

    @Override
    public int hashCode() {
        return Objects.hash(robotId, robotName, robotCompany, robotAxes, robotArmLength, robotReach,
            robotLoadWeight, robotMass, robotRepeatability);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Robot {\n");

        sb.append("    robotId: ").append(toIndentedString(robotId)).append("\n");
        sb.append("    ronotName: ").append(toIndentedString(robotName)).append("\n");
        sb.append("    robotCompany: ").append(toIndentedString(robotCompany)).append("\n");
        sb.append("    robotAxes: ").append(toIndentedString(robotAxes)).append("\n");
        sb.append("    robotArmLength: ").append(toIndentedString(robotArmLength)).append("\n");
        sb.append("    robotReach: ").append(toIndentedString(robotReach)).append("\n");
        sb.append("    robotLoadWeight: ").append(toIndentedString(robotLoadWeight)).append("\n");
        sb.append("    robotMass: ").append(toIndentedString(robotMass)).append("\n");
        sb.append("    robotRepeatability: ").append(toIndentedString(robotRepeatability))
            .append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(java.lang.Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}
