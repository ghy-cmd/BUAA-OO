package com.vision_aiot.repositories;

import com.vision_aiot.model.Box;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BoxRepository extends JpaRepository<Box, Long> {
    List<Box> findByUsername(String username);
}
