package com.vision_aiot.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vision_aiot.model.Role;
import com.vision_aiot.model.User;
import com.vision_aiot.security.SecurityUtils;
import com.vision_aiot.services.UserService;
import com.vision_aiot.services.UserServiceImpl;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-04T02:40:14.269Z[GMT]")
@RestController
// 允许跨域
@CrossOrigin
public class UserApiController implements UserApi {

    private static final Logger log = LoggerFactory.getLogger(UserApiController.class);
    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    private UserService userService;

    @org.springframework.beans.factory.annotation.Autowired
    public UserApiController(ObjectMapper objectMapper, HttpServletRequest request,
                             UserService userService) {
        this.objectMapper = objectMapper;
        this.request = request;
        this.userService = userService;
    }

    public ResponseEntity<Void> createUser(
        @Parameter(in = ParameterIn.DEFAULT, description = "Created user object", required = true, schema = @Schema())
        @Valid @RequestBody User body) {
        String accept = request.getHeader("Accept");
        int result = userService.addUser(body);
        switch (result) {
            case 200:
                return new ResponseEntity<>(HttpStatus.OK);
            case 201:
                return new ResponseEntity<>(HttpStatus.CREATED);
            case 401:
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            case 404:
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            default:
                return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
        }
    }

    public ResponseEntity<Void> createUsersWithArrayInput(
        @Parameter(in = ParameterIn.DEFAULT, description = "List of user object", required = true, schema = @Schema())
        @Valid @RequestBody List<User> body) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }


    public ResponseEntity<Void> createUsersWithListInput(
        @Parameter(in = ParameterIn.DEFAULT, description = "List of user object", required = true, schema = @Schema())
        @Valid @RequestBody List<User> body) {
        String accept = request.getHeader("Accept");
        int result = userService.creatUsersWithListInput(body);
        switch (result) {
            case 200:
                return new ResponseEntity<>(HttpStatus.OK);
            case 201:
                return new ResponseEntity<>(HttpStatus.CREATED);
            case 401:
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            case 404:
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            default:
                return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
        }
    }

    public ResponseEntity<Void> deleteUser(
        @Parameter(in = ParameterIn.PATH, description = "The name that needs to be deleted", required = true, schema = @Schema())
        @PathVariable("username") String username) {
        String accept = request.getHeader("Accept");
        if (accept == null) {
            return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
        } else {
//                if (userService.findUserByUserUsername(username) == null) {
//                    return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
//                } else {
//                    userService.deleteUser(username);
//                    return new ResponseEntity<Void>(HttpStatus.OK);
//                }

            int result = userService.deleteUser(username);
            switch (result) {
                case 200:
                    return new ResponseEntity<>(HttpStatus.OK);
                case 204:
                    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
                case 400:
                    return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
                case 401:
                    return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
                case 404:
                    return new ResponseEntity<>(HttpStatus.NOT_FOUND);
                default:
                    return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
            }
        }
    }

    public ResponseEntity<User> getUserByName(
        @Parameter(in = ParameterIn.PATH, description = "The name that needs to be fetched. Use user1 for testing. ", required = true, schema = @Schema())
        @PathVariable("username") String username) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            Collection authorities = SecurityUtils.getCurrentUserAuthorities();
            String currentUsername = SecurityUtils.getCurrentUsername().get();
            boolean isAdmin = false;
            boolean isNull = !userService.findUserByUserUsername(username).isPresent();
            for (Object authority : authorities) {
                GrantedAuthority grantedAuthority = (GrantedAuthority) authority;
                if (grantedAuthority.getAuthority().equals("ROLE_ADMIN")) {
                    isAdmin = true;
                    break;
                }
            }

            // User as admin or as themself can access userInfo.
            if (!isNull && (isAdmin || currentUsername.equals(username))) {
                User user = userService.findUserByUserUsername(username).get();
                // disable password.
                user.setUserPassword(null);

                // disable roles users
                Iterator<Role> iterator = user.getRoles().iterator();
                while (iterator.hasNext()) {
                    iterator.next().setUsers(null);
                }

                return new ResponseEntity<User>(user, HttpStatus.OK);
//                    return new ResponseEntity<User>(objectMapper.readValue(
//                        "{\n  \"user_status\" : " + user.getUserStatus() +
//                            ",\n  \"user_password\" : " + user.getUserPassword() +
//                            ",\n  \"user_email\" : " + user.getUserEmail() +
//                            ",\n  \"user_id\" : " + user.getUserId() +
//                            " ,\n  \"user_username\" : " + user.getUserUsername() +
//                            ",\n  \"user_name\" : " + user.getUserName() +
//                            ",\n  \"user_telephone\" : " + user.getUserTelephone() +
//                            ",\n  \"user_phone\" : " + user.getUserPhone() + "\n}",
//                        User.class), HttpStatus.OK);
            } else if (isNull) {
                return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
            } else {
                return new ResponseEntity<User>(HttpStatus.FORBIDDEN);
            }
        }
        return new ResponseEntity<User>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> logoutUser() {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.OK);
    }

    public ResponseEntity<Void> updateUser(
        @Parameter(in = ParameterIn.PATH, description = "name that need to be updated", required = true, schema = @Schema())
        @PathVariable("username") String username,
        @Parameter(in = ParameterIn.DEFAULT, description = "Updated user object", required = true, schema = @Schema())
        @Valid @RequestBody User body) {
        String accept = request.getHeader("Accept");
        switch (userService.updateUser(username, body)) {
            case 200:
                return new ResponseEntity<>(HttpStatus.OK);
            case 401:
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            case 404:
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            default:
                return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
        }
    }
}