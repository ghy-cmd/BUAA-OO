package com.vision_aiot.services;

import com.vision_aiot.model.Grasper;

import java.util.List;
import java.util.Optional;

public interface GrasperService {
    int creatGrasper(Grasper grasper);

    int creatGrasperWithListInput(List<Grasper> graspers);

    int deleteGrasper(String grasperId);

    Optional<Grasper> findGrasperByGrasperId(Long grasperId);

    List<Grasper> findAll();

    int updateGrasper(String grasperId, Grasper grasper);
}
