package com.vision_aiot.api.exception;

public class NoBoxException extends RuntimeException {
    public NoBoxException() {
    }
    
    public NoBoxException(String message) {
        super(message);
    }
    
    public NoBoxException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public NoBoxException(Throwable cause) {
        super(cause);
    }
    
    public NoBoxException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
