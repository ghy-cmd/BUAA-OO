package com.vision_aiot.repositories;

import com.vision_aiot.model.Device;
import com.vision_aiot.model.Robot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface DeviceRepository extends JpaRepository<Device, Long> {
    List<Device> findAll();

    Optional<Device> findDeviceByDeviceId(Long deviceId);

    void deleteDeviceByDeviceId(Long deviceId);

}
