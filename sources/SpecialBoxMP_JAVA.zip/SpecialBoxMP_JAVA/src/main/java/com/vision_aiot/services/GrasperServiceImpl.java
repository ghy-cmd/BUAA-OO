package com.vision_aiot.services;

import com.vision_aiot.model.Grasper;
import com.vision_aiot.repositories.GrasperRepository;
import com.vision_aiot.security.SecurityUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GrasperServiceImpl implements GrasperService {

    private final GrasperRepository grasperRepository;

    public GrasperServiceImpl(GrasperRepository grasperRepository) {
        this.grasperRepository = grasperRepository;
    }

    @Override
    public int creatGrasper(Grasper grasper) {
        if (SecurityUtils.isAdmin() &&
            !grasperRepository.findGrasperByGrasperName(grasper.getGrasperName()).isPresent()) {
            grasperRepository.save(grasper);
            return 201;
        } else if (grasperRepository.findGrasperByGrasperName(grasper.getGrasperName())
            .isPresent()) {
            return 409;
        } else {
            return 403;
        }
    }

    @Override
    public int creatGrasperWithListInput(List<Grasper> graspers) {
        Boolean isPresent = false;
        for (Grasper grasper : graspers) {
            if (grasperRepository.findGrasperByGrasperName(grasper.getGrasperName()).isPresent()) {
                isPresent = true;
                break;
            }
        }

        if (SecurityUtils.isAdmin() && !isPresent) {
            for (Grasper grasper : graspers) {
                grasperRepository.save(grasper);
            }
            return 201;
        } else if (isPresent) {
            return 409;
        } else {
            return 403;
        }
    }

    @Override
    public int deleteGrasper(String grasperId) {
        try {
            Long id = Long.parseLong(grasperId);
        } catch (NumberFormatException e) {
            return 400;
        }
        if (grasperRepository.findGrasperByGrasperId(Long.parseLong(grasperId)).isPresent() &&
            SecurityUtils.isAdmin()) {
            grasperRepository.deleteGrasperByGrasperId(Long.parseLong(grasperId));
            return 200;
        } else if (grasperRepository.findAll().isEmpty()) {
            return 204;
        } else if (!SecurityUtils.isAdmin()) {
            return 403;
        } else {
            return 404;
        }
    }

    @Override
    public Optional<Grasper> findGrasperByGrasperId(Long grasperId) {
        return grasperRepository.findGrasperByGrasperId(grasperId);
    }

    @Override
    public List<Grasper> findAll() {
        return grasperRepository.findAll();
    }

    @Override
    public int updateGrasper(String grasperId, Grasper grasper) {
        try {
            Long id = Long.parseLong(grasperId);
        } catch (NumberFormatException e) {
            return 400;
        }
        if (grasperRepository.findGrasperByGrasperId(Long.parseLong(grasperId)).isPresent() &&
            SecurityUtils.isAdmin()) {
            grasperRepository.deleteGrasperByGrasperId(Long.parseLong(grasperId));
            grasperRepository.save(grasper);
            return 200;
        } else if (grasperRepository.findAll().isEmpty()) {
            return 204;
        } else if (!SecurityUtils.isAdmin()) {
            return 401;
        } else {
            return 404;
        }
    }
}
