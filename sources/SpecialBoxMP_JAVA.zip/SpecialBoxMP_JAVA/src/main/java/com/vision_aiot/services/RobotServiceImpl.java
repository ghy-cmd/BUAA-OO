package com.vision_aiot.services;

import com.vision_aiot.model.User;
import com.vision_aiot.repositories.RobotRepository;
import com.vision_aiot.security.SecurityUtils;
import com.vision_aiot.model.Robot;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;


import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Service
public class RobotServiceImpl implements RobotService {
    private final RobotRepository robotRepository;

    public RobotServiceImpl(RobotRepository robotRepository) {
        this.robotRepository = robotRepository;
    }

    @Override
    public int creatRobot(Robot robot) {

        boolean ispresent = robotRepository.findRobotByRobotId(robot.getRobotId()).isPresent();
        if (ispresent) {
            return 409;
        } else if (SecurityUtils.isAdmin()) {
            robotRepository.save(robot);
            return 201;
        } else {
            return 403;
        }
    }

    @Override
    public int creatRobotWithListInput(List<Robot> robots) {

        boolean isPresent = false;

        for (Robot robot : robots) {
            if (robotRepository.findRobotByRobotId(robot.getRobotId()).isPresent()) {
                isPresent = true;
                break;
            }
        }
        if (isPresent) {
            return 409;
        } else if (SecurityUtils.isAdmin()) {
            for (Robot robot : robots) {
                robotRepository.save(robot);
            }
            return 201;
        } else {
            return 403;
        }
    }

    @Override
    public int deleteRobot(String robotId) {
        try {
            Long id = Long.parseLong(robotId);
        } catch (NumberFormatException e) {
            return 400;
        }

        if (robotRepository.findRobotByRobotId(Long.parseLong(robotId)).isPresent() &&
            SecurityUtils.isAdmin()) {
            robotRepository.deleteRobotByRobotId(Long.parseLong(robotId));
            return 200;
        } else if (robotRepository.findAll().isEmpty()) {
            return 204;
        } else if (!SecurityUtils.isAdmin()) {
            return 401;
        } else {
            return 404;
        }
    }

    @Override
    public Optional<Robot> findRobotByRobotId(Long robotId) {
        return robotRepository.findRobotByRobotId(robotId);
    }

    @Override
    public List<Robot> findAll() {
        return robotRepository.findAll();
    }

    @Override
    public int updateRobot(String robotId, Robot robot) {
        try {
            Long id = Long.parseLong(robotId);
        } catch (NumberFormatException e) {
            return 400;
        }
        if (robotRepository.findRobotByRobotId(Long.parseLong(robotId)).isPresent() &&
            SecurityUtils.isAdmin()) {
            robotRepository.deleteRobotByRobotId(Long.parseLong(robotId));
            robotRepository.save(robot);
            return 200;
        } else if (robotRepository.findAll().isEmpty()) {
            return 204;
        } else if (!SecurityUtils.isAdmin()) {
            return 401;
        } else {
            return 404;
        }
    }
}
