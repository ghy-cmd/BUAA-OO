package com.vision_aiot.repositories;

import com.vision_aiot.model.Role;
import com.vision_aiot.model.User;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Optional;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class UserRepositoryTest {
    
    @Autowired
    UserRepository userRepository;
    
    @Autowired
    PasswordEncoder passwordEncoder;
    
    @Test
    public void save() {
        User u = new User();
        u.setUserName("李四");
        u.setUserUsername("admin");
        u.setUserPassword(passwordEncoder.encode("admintest123"));
        u.setUserEmail("admin@test.com");
        u.setUserPhone("15007753333");
        u.setUserTelephone("080-2508031");
        u.setUserStatus(0);
        Role admin = new Role();
        admin.setRoleId(1L);
        admin.setRoleName("ADMIN");
        u.getRoles().add(admin);
        User result = userRepository.save(u);
        Assert.assertEquals(result.getUserName(), u.getUserName());
    }
}