package com.vision_aiot.services;

import com.vision_aiot.model.User;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedList;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@WithMockUser(username = "admin", roles = {"ADMIN", "EMPLOYEE"})
public class UserServiceTest {
    @Autowired
    private UserService userService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Test
    @Transactional
    public void getUsersTest() {
        List<User> users = new LinkedList<User>();
        User testUser = new User();
        testUser.setUserUsername("test");
        testUser.setUserName("testname");
        testUser.setUserPassword(passwordEncoder.encode("test123456"));
        testUser.setUserPhone("1111111");
        testUser.setUserEmail("test@admin.com");
        testUser.setUserStatus(1);
        users.add(testUser);
        User testUser1 = new User();
        testUser1.setUserUsername("ggg");
        testUser1.setUserPassword(passwordEncoder.encode("98yg"));
        testUser1.setUserPhone("1111111");
        testUser1.setUserEmail("iyugb");
        testUser1.setUserStatus(1);
        users.add(testUser1);
        userService.addUser(testUser);
        int result = userService.updateUser("test", testUser1);
        Assert.assertEquals(200, result);
    }
}
