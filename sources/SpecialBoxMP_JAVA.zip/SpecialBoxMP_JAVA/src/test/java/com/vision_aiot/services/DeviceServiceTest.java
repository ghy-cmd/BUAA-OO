package com.vision_aiot.services;

import com.vision_aiot.model.Device;
import com.vision_aiot.model.Grasper;
import com.vision_aiot.model.Robot;
import org.checkerframework.checker.units.qual.A;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@WithMockUser(username = "admin", roles = {"ADMIN", "EMPLOYEE"})
public class DeviceServiceTest {
    @Autowired
    private DeviceService deviceService;

    private RobotService robotService;

    private GrasperService grasperService;

    @Test
    @Transactional
    public void creatDeviceTest() {
        //deviceService.deleteDevice("1004");

        Device device = new Device();
        device.setDeviceId(Long.parseLong("20"));
        device.setDevicePoseX(Double.valueOf("2"));
        device.setDevicePoseY(Double.valueOf("1"));
        device.setDevicePoseZ(Double.valueOf("1"));
        device.setDevicePositionX(Double.valueOf("1"));
        device.setDevicePositionY(Double.valueOf("1"));
        device.setDevicePositionZ(Double.valueOf("1"));
        Robot robot1 = new Robot();
        robot1.setRobotName("test");
        device.setRobot(robot1);
        Grasper grasper1 = new Grasper();
        grasper1.setGrasperName("test");
        device.setGrasper(grasper1);
        //int result=deviceService.updateDevice("1004",device);
        int result = deviceService.creatDevice(device);
       /* Robot robot = new Robot();
        robot.setRobotName("test");
        robot.setRobotAxes(3);
        robot.setRobotReach(Double.valueOf("123"));
        robot.setRobotCompany("hgg");
        robot.setRobotMass(Double.valueOf("8878"));
        robot.setRobotArmLength(Double.valueOf("7"));
        robot.setRobotRepeatability(true);
        robot.setRobotLoadWeight(Double.valueOf("98788"));
        robotService.creatRobot(robot);

        Grasper grasper = new Grasper();
        grasper.setGrasperCompany("hgg");
        grasper.setGrasperName("test");
        grasperService.creatGrasper(grasper);*/
        Assert.assertEquals(201, result);
    }

    @Test
    @Transactional
    public void creatDevicesTest() {
        Device device = new Device();
        device.setDeviceId(Long.parseLong("20"));
        device.setDevicePoseX(Double.valueOf("2"));
        device.setDevicePoseY(Double.valueOf("1"));
        device.setDevicePoseZ(Double.valueOf("1"));
        device.setDevicePositionX(Double.valueOf("1"));
        device.setDevicePositionY(Double.valueOf("1"));
        device.setDevicePositionZ(Double.valueOf("1"));
        Robot robot1 = new Robot();
        robot1.setRobotName("test");
        device.setRobot(robot1);
        Grasper grasper1 = new Grasper();
        grasper1.setGrasperName("test");
        device.setGrasper(grasper1);
        List<Device> deviceList = new ArrayList<>();
        deviceList.add(device);
        int result = deviceService.creatDeviceWithListInput(deviceList);
        Assert.assertEquals(201, result);
    }

    @Test
    @Transactional
    public void deleteDeviceTest() {
        int result = deviceService.deleteDevice("1005");
        Assert.assertEquals(200, result);
    }

    @Test
    @Transactional
    public void updateDeviceTest() {
        Device device = new Device();
        device.setDeviceId(Long.parseLong("20"));
        device.setDevicePoseX(Double.valueOf("2"));
        device.setDevicePoseY(Double.valueOf("1"));
        device.setDevicePoseZ(Double.valueOf("1"));
        device.setDevicePositionX(Double.valueOf("1"));
        device.setDevicePositionY(Double.valueOf("1"));
        device.setDevicePositionZ(Double.valueOf("1"));
        Robot robot1 = new Robot();
        robot1.setRobotName("test");
        device.setRobot(robot1);
        Grasper grasper1 = new Grasper();
        grasper1.setGrasperName("test");
        device.setGrasper(grasper1);
        int result = deviceService.updateDevice("1005", device);
        Assert.assertEquals(200, result);
    }
}
