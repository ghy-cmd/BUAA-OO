package com.vision_aiot.services;

import com.vision_aiot.model.Grasper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@WithMockUser(username = "admin", roles = {"ADMIN", "EMPLOYEE"})
public class GrasperServiceTest {
    @Autowired
    private GrasperService grasperService;

    @Test
    @Transactional
    public void creatGrasperTest() {
        Grasper grasper = new Grasper();
        grasper.setGrasperName("test1");
        grasper.setGrasperCompany("hgg");
        int result = grasperService.creatGrasper(grasper);
        Assert.assertEquals(201, result);
    }

    @Test
    @Transactional
    public void creatGrasperWithListTest() {
        Grasper grasper = new Grasper();
        grasper.setGrasperName("test1");
        grasper.setGrasperCompany("hgg");
        Grasper grasper1 = new Grasper();
        grasper1.setGrasperName("test2");
        grasper1.setGrasperCompany("hgg");
        List<Grasper> graspers = new ArrayList<>();
        graspers.add(grasper);
        graspers.add(grasper1);
        int result = grasperService.creatGrasperWithListInput(graspers);
        Assert.assertEquals(201, result);
    }

    @Test
    @Transactional
    public void deleteGrasperTest() {
        /*Grasper grasper = new Grasper();
        grasper.setGrasperId(Long.valueOf("1009"));
        grasper.setGrasperName("test1");
        grasper.setGrasperCompany("hgg");
        grasperService.creatGrasper(grasper);*/
        int result = grasperService.deleteGrasper("1001");
        Assert.assertEquals(200, result);
    }

    @Test
    @Transactional
    public void updateGrasperTest() {
        Grasper grasper = new Grasper();
        grasper.setGrasperId(Long.valueOf("1009"));
        grasper.setGrasperName("test1");
        grasper.setGrasperCompany("hgg");
        int result = grasperService.updateGrasper("1001", grasper);
        Assert.assertEquals(200, result);
    }
}
