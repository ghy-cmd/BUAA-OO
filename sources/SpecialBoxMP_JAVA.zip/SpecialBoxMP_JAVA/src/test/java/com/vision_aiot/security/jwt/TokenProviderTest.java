package com.vision_aiot.security.jwt;

import com.vision_aiot.model.Role;
import com.vision_aiot.repositories.RoleRepository;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Collection;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TokenProviderTest {
    @Autowired
    TokenProvider tokenProvider;
    
    @Autowired
    PasswordEncoder passwordEncoder;
    
    @Test
    public void JwtsTest() {
        Collection<GrantedAuthority> collection = new ArrayList<>();
        GrantedAuthority grantedAuthority = new SimpleGrantedAuthority("admin");
        collection.add(grantedAuthority);
        Authentication authentication = new UsernamePasswordAuthenticationToken("admin", "test123", collection);
        String jwt = tokenProvider.createToken(authentication, true);
        boolean isSuccess = tokenProvider.validateToken(jwt);
        authentication = tokenProvider.getAuthentication(jwt);
        assert (isSuccess);
        assert (!authentication.getAuthorities().isEmpty());
    }
    
    @Test
    public void PasswordEncoderTest() {
        String password = passwordEncoder.encode("admin");
//        System.out.println(password);
        Assert.assertTrue(passwordEncoder.matches("admin", password));
    }
}
