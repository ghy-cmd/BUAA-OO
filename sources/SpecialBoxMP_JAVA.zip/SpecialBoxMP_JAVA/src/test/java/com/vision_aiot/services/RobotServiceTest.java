package com.vision_aiot.services;

import com.vision_aiot.model.Robot;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@WithMockUser(username = "admin", roles = {"ADMIN", "EMPLOYEE"})
public class RobotServiceTest {
    @Autowired
    private RobotService robotService;

    @Test
    @Transactional
    public void creatRobotTest() {
        Robot robot = new Robot();
        robot.setRobotName("test");
        robot.setRobotAxes(3);
        robot.setRobotReach(Double.valueOf("123"));
        robot.setRobotCompany("hgg");
        robot.setRobotMass(Double.valueOf("8878"));
        robot.setRobotArmLength(Double.valueOf("7"));
        robot.setRobotRepeatability(true);
        robot.setRobotLoadWeight(Double.valueOf("98788"));
        int result = robotService.creatRobot(robot);
        Assert.assertEquals(201, result);
    }

    @Test
    @Transactional
    public void creatRobotWithListTest() {
        Robot robot = new Robot();
        robot.setRobotName("test");
        robot.setRobotAxes(3);
        robot.setRobotReach(Double.valueOf("123"));
        robot.setRobotCompany("hgg");
        robot.setRobotMass(Double.valueOf("8878"));
        robot.setRobotArmLength(Double.valueOf("7"));
        robot.setRobotRepeatability(true);
        robot.setRobotLoadWeight(Double.valueOf("98788"));
        List<Robot> robots = new ArrayList<>();
        robots.add(robot);
        int result = robotService.creatRobotWithListInput(robots);
        Assert.assertEquals(201, result);
    }

    @Test
    @Transactional
    public void deleteRobotTest() {
        int result = robotService.deleteRobot("10000027");
        Assert.assertEquals(200, result);
    }

    @Test
    @Transactional
    public void updateRobotTest() {
        Robot robot = new Robot();
        robot.setRobotName("test");
        robot.setRobotAxes(3);
        robot.setRobotReach(Double.valueOf("123"));
        robot.setRobotCompany("hgg");
        robot.setRobotMass(Double.valueOf("8878"));
        robot.setRobotArmLength(Double.valueOf("7"));
        robot.setRobotRepeatability(true);
        robot.setRobotLoadWeight(Double.valueOf("98788"));
        int result = robotService.updateRobot("10000027", robot);
        Assert.assertEquals(200, result);
    }
}
