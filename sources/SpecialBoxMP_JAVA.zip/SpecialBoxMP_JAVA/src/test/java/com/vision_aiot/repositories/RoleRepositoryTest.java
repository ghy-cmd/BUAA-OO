package com.vision_aiot.repositories;

import com.vision_aiot.model.Role;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class RoleRepositoryTest {
    @Autowired
    private RoleRepository roleRepository;
    
    @Test
    public void saveRole() {
        Role role = new Role();
        role.setRoleName("ADMIN");
        roleRepository.save(role);
    }
}
